import React from 'react';
import { Route, Switch } from 'react-router-dom';
import HomePage from '../home/HomePage';
import SubmissionsView from '../submissions/SubmissionsView';
import OcrView from '../submissions/OcrView';

const AppRoutes = () => {
  return (
    <>
      <Switch>
        <Route exact path="/" render={props => <HomePage {...props} />} />
        <Route exact path="/ocr" render={props => <SubmissionsView {...props} />} />
        <Route exact path="/ocrui" render={props => <OcrView {...props} />} />
        <Route exact path="/submissions" render={props => <SubmissionsView {...props} />} />
      </Switch>
    </>
  );
};

export default AppRoutes;
