import React from 'react';
import { TabNavigation } from './TabNavigation';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';

jest.mock('react-router-dom', () => {
    const historyObj = {
        push: jest.fn()
    };

    return {
        ...jest.requireActual('react-router-dom'),
        useHistory: () => historyObj,
        useLocation: () => ({
            pathname: "/"
        })
    }
});

const wrapper = shallow(<TabNavigation />);

describe('TabNavigation component', () => {
    it('should render correctly', () => {
        expect(wrapper.exists()).toBe(true);
    });

    it('should match the snapshot', () => {
        expect(wrapper).toMatchSnapshot(true);

        let tree = renderer
            .create(<TabNavigation />)
            .toJSON();
        expect(tree).toMatchSnapshot();
    })
});