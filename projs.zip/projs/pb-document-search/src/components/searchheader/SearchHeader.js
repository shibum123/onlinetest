import React from 'react';
import logo from '../../assets/axa-logo.png';
import brandinglogo from '../../assets/deep-ai.svg';

import './SearchHeader.scss';
import { useHistory } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

export const SearchHeader = (props) => {
  const history = useHistory();
  const { t } = useTranslation();
  const onLogoClick = () => {
    history.push({
      pathname: '/',
      state: { searchText: '' },
    });
  };
  const handleKeyDown = (evt) => {
    if (evt.key === 'Enter') {
      onLogoClick();
    }
  };

  return (
    <div className="search-header">
      <hr className="search-header__hr-header" />
      <div className="search-header__title-header">
        <p className="search-header__logo">
          <img
            src={logo}
            tabIndex="1"
            alt="axa logo"
            onKeyDown={handleKeyDown}
            className="search-header__logo-image"
            onClick={() => onLogoClick()}
          />
          {props.showBrandingLogo && (
            <img
              src={brandinglogo}
              alt="deep ai logo"
              className="search-header__branding-logo"
              onKeyDown={handleKeyDown}
              onClick={() => onLogoClick()}
            />
          )}
        </p>
        <h3
          className="search-header__title search-header__title-text"
          data-testid="searchtool-text">
          {t('searchheader_searchtool')}
          <span className="search-header__title-version">&nbsp;v1.0</span>
        </h3>
        {props.enableLogin && (
          <div className="search-header__user-details">
            <div className="dropdown">
              <button
                type="button"
                className="btn dropdown-toggle"
                data-toggle="dropdown">
                {props.loggedUser && props.loggedUser.name
                  ? props.loggedUser.name
                  : ''}
              </button>
              <div className="dropdown-menu">
                <a
                  id="searchLogout"
                  className="dropdown-item"
                  onClick={() => props.logout()}>
                  {t('logout')}
                </a>
              </div>
            </div>
          </div>
        )}
      </div>
      <hr className="search-header__hr-header-bottom" />
    </div>
  );
};
