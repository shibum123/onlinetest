// import { takeLatest } from 'redux-saga/effects';

// This is the watcher saga. Whenever a reducer duck is made that requires Redux Saga to make outgoing API requests
// Make a file with the same name as the duck in the handlers and requests folder as well
export function* watcherSaga() {
  // yield takeLatest(ACTION_NAME, handleActionName);
}
