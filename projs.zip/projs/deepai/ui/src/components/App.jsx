import React from 'react';
import BaseLayout from './layout/BaseLayout';

const App = () => {
  return (
    <>
      <BaseLayout />
    </>
  );
};

export default App;
