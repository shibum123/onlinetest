import React, { useState, useEffect, useContext } from 'react';
import { pdfjs, Page } from 'react-pdf';
import './DetailedView.scss';
import { useTranslation } from 'react-i18next';
import { ShowDocument } from '../showdocument/ShowDocument';
import { SearchContext } from '../../App';

const DetailedView = (prop) => {
  // const [pages, setPages] = useState([]);
  const [url, setUrl] = useState(
    prop.dataList[0] ? prop.dataList[0].filetype : null,
  );
  const { t } = useTranslation();

  const isDisabled = true;

  const searchContext = useContext(SearchContext);

  const [currentPage, setCurrentPage] = useState(1);
  const [paginatedData, setPaginatedData] = useState(null);
  const [selectedId, setSelectedId] = useState(null);
  const [selectedItem, setSelectedItem] = useState(
    prop.selectedDoc ? prop.selectedDoc : null,
  );

  pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;

  useEffect(() => {
    if (
      searchContext &&
      searchContext.searchState &&
      searchContext.searchState.selectedItemChange
    ) {
      setSelectedItem(searchContext.searchState.selectedItemChange);
      setUrl(searchContext.searchState.selectedItemChange.url);
      setSelectedId(searchContext.searchState.selectedItemChange._id);
      setCurrentPage(1);
    } else if (prop.dataList[0]) {
      setSelectedItem(prop.dataList[0]);
      setUrl(prop.dataList[0].url);
      setSelectedId(prop.dataList[0]._id);
      setCurrentPage(1);
    } else {
      setSelectedItem(null);
      setUrl(null);
      setSelectedId(null);
      setCurrentPage(-1);
    }
  }, [prop]);

  useEffect(() => {
    setPaginatedData(<Page key={currentPage} pageNumber={currentPage} />);
  }, [currentPage]);

  const onClick = async (event, item) => {
    event.preventDefault();
    setCurrentPage(1);
    setSelectedId(item._id);
    setUrl(item.url);
    setSelectedItem(item);
    searchContext.searchDispatch({
      type: 'SELECTED_ITEM_CHANGE',
      value: item,
    });
  };

  /*   const onFileDownload = (event) => {
    event.preventDefault();
    axios({
      url: selectedItem.url, //your url
      method: 'GET',
      responseType: 'blob', // important
    })
      .then((response) => {
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', selectedItem.filename); //or any other extension
        document.body.appendChild(link);
        link.click();
      })
      .catch((error) => {
        console.log('Something went wrong! Unable to download.');
      });
  }; */

  /* const onError = () => {
    setPages(0);
    setShowDownload(false);
  }; */

  const noResults = !(prop.dataList && prop.dataList.length > 0);

  return (
    <div className="detailed-view">
      <div
        data-testid="list-item"
        className="list-group detailed-view__left-column">
        {prop.dataList &&
          prop.dataList.map((item, index) => {
            return (
              <div
                key={index}
                className={
                  item._id === selectedId
                    ? 'detailed-view__list-item-selected'
                    : 'detailed-view__list-item'
                }
                onClick={(event) => onClick(event, item)}>
                <div className="detailed-view__title">
                  <div className="detailed-view__link-item">
                    {item.filename}
                  </div>
                  <div className="detailed-view__title-text">
                    {item.create_date}
                  </div>
                </div>
                {t('detail_submission')}
              </div>
            );
          })}
      </div>
      <div className="detailed-view__right-column">
        <div className="detailed-view__pdf-title-row">
          <div className="detailed-view__pdf-title">
            {selectedItem ? selectedItem.title : ''}
          </div>
          <div className="detailed-view__pdf-xid">
            {selectedItem && selectedItem.xId
              ? `XLID - ${selectedItem.xId}`
              : ''}
          </div>
          <div className="detailed-view__pdf-download">
            {/* {selectedItem && selectedItem.url && showDownload && (
              <React.Fragment>
                <a href="#" onClick={(event) => onFileDownload(event)}>
                  <img
                    className="detailed-view__img_download"
                    src={arrowDownload}
                  />
                  {t('detail_download')}
                </a>
              </React.Fragment>
            )} */}
          </div>
        </div>
        <ShowDocument
          document={selectedItem}
          searchWords={prop.searchString.split(' ')}
        />
        {!isDisabled && url && paginatedData && (
          <React.Fragment>
            {/* {fileType === '.pdf' && content && (
              <Document
                file={content}
                onLoadSuccess={onDocumentLoadSuccess}
                onLoadError={() => onError()}>
                {paginatedData}
              </Document>
            )}
            {fileType !== '.pdf' && (
              <iframe
                className="detailed-view__fileviwer"
                target="_self"
                frameBorder="0"
                fileType={fileType.split('.')[1]}
                src={url}></iframe>
            )} */}
            {/*  {content && (
              <button onClick={() => onPrev()} disabled={currentPage < 2}>
                &lt;&lt;
              </button>
            )}
            {content && (
              <button
                onClick={() => onNext()}
                disabled={
                  (currentPage > pages.length - 1 && pages.length > 1) ||
                  pages <= 0
                }>
                &gt;&gt;
              </button>
            )} */}
          </React.Fragment>
        )}
        {!noResults && !selectedItem.content && (
          <React.Fragment>
            <p className="detailed-view__no-preview">
              {t('detail_no_preview')}
            </p>
          </React.Fragment>
        )}
        {noResults && (
          <React.Fragment>
            <p className="detailed-view__no-preview">
              {t('detail_no_results')}
            </p>
          </React.Fragment>
        )}
      </div>
    </div>
  );
};

export { DetailedView };
