import axios from 'axios';
const headers = {
    headers: {
        "content-type": "application/json",
    }
}

const formdataheaders = {
    headers: {
        'Content-Type': 'multipart/form-data'
    }
}

const getAPIPrefix = () => {
    if (window.location.pathname === '/ocr') {
        return 'x2txt'
    } else {
        return 'sub'
    }
}

export class RestAPIClient {

    static async getUser() {
        return await axios.get('/api/user');
    }

    static async getSubmissions() {
        return await axios.get(`/api/services/${getAPIPrefix()}/submissions`);
    }

    static async getPrimaryParties(req) {
        return await axios.get(`/api/services/submission-report/${req.partySubmissionId}`);
    }

    static async setPrimaryParty(req) {
        return await axios.post(`/api/services/submission-report/${req.partySubmissionId}/select-primary/${req.companyId}`);
    }

    static async getProcessingStatus(submissionIds) {
        const axiosArray = [];
        submissionIds.forEach((id) => {
            axiosArray.push(axios({
                method: 'get',
                url: `/api/services/${getAPIPrefix()}/submission-progress/${id}`
            }))
        })
        return await axios.all(axiosArray)
    }

    static async editSubmission(req, selectedSubmissionId) {
        if (req.files.length > 0 || req.removed.length > 0) {
            const axiosArray = [];
            req.removed.forEach(() => {
                axiosArray.push(axios({
                    method: 'post',
                    url: `/api/services/${getAPIPrefix()}/remove-submission-file/${selectedSubmissionId}`
                }))
            })
            req.files.forEach(file => {
                if (!file.id) {
                    const content = file.fileContent.substring(file.fileContent.indexOf(';base64,') + 8, file.fileContent.length)
                    axiosArray.push(axios({
                        method: 'post',
                        url: `/api/services/${getAPIPrefix()}/add-file-to-submission/${selectedSubmissionId}`,
                        data: {
                            fileName: file.fileName,
                            fileType: file.fileType,
                            fileContent: content
                        }
                    }))
                }
            })
            return await axios.all(axiosArray)
                .then(async () => {
                    if (!req.isDraft) {
                        await axios.post(`/api/services/${getAPIPrefix()}/finalise-submission/${selectedSubmissionId}`, {
                        }, headers)
                            .then(() => true)
                    } else {
                        return true;
                    }
                })
        } else {
            if (!req.isDraft) {
                return await axios.post(`/api/services/${getAPIPrefix()}/finalise-submission/${selectedSubmissionId}`, {
                }, headers)
                    .then(() => true)
            } else {
                return true;
            }
        }
    }

    static async createSubmission(req) {
        return await axios.post(`/api/services/${getAPIPrefix()}/create-submission/`, {
            "name": req.name
        }, headers).then(async resp => {
            if (req.files.length > 0) {
                const axiosArray = req.files.map(file => {
                    const content = file.fileContent.substring(file.fileContent.indexOf(';base64,') + 8, file.fileContent.length)
                    return axios({
                        method: 'post',
                        url: `/api/services/${getAPIPrefix()}/add-file-to-submission/${resp.data.submissionId}`,
                        data: {
                            fileName: file.fileName,
                            fileType: file.fileType,
                            fileContent: content
                        }
                    })
                });
                return await axios.all(axiosArray)
                    .then(async () => {
                        if (!req.isDraft) {
                            return await axios.post(`/api/services/${getAPIPrefix()}/finalise-submission/${resp.data.submissionId}`, {
                            }, headers)
                                .then(() => true)
                        } else {
                            return true;
                        }
                    })
            } else {
                if (!req.isDraft) {
                    axios.post(`/api/services/${getAPIPrefix()}/finalise-submission/${resp.data.submissionId}`, {
                    }, headers)
                        .then(() => true)
                } else {
                    return true;
                }
            }
        })
    }

    static async onConvertToText(file, isSearchablePDF) {
        const dataArray = new FormData();
        dataArray.append("file", file[0]);
        return await axios
            .post(`http://10.226.52.102:5000/doc-to-text?stripnewlines=n&OCRLanguage=eng&searchablePDF=${isSearchablePDF}`,
                dataArray,
                formdataheaders
            )
    }

    static async getSubmissionStatus(submissionId) {
        return await axios.post(`/api/services/${getAPIPrefix()}/submissions/${submissionId}`);
    }

    static async downloadSubmissionFile(selectedFileIds) {
        const axiosArray = selectedFileIds.map(file => {
            return axios({
                method: 'get',
                url: `/api/services/${getAPIPrefix()}/download-submission-file/${file.input.id}`
            })
        })
        return await axios.all(axiosArray)
    }

    static async deleteSubmission(submissionId) {
        return await axios.post(`/api/services/${getAPIPrefix()}/remove-submission/${submissionId}`);
    }
}

export default RestAPIClient;
