import React from 'react';
import './Login.scss';
import { SearchHeader } from '../searchheader/SearchHeader';
import logo from '../../assets/deep-ai.svg';
import { useTranslation } from 'react-i18next';

export const Login = (props) => {
  const { t } = useTranslation();
  return (
    <div className="login">
      <SearchHeader enableLogin={false} />
      <div className="login__help">
        <div className="login__help-circle">
          <div className="login__help-circle-text">?</div>
          <span className="login__help__tool-tip">{t('search_ui')}</span>
        </div>
        {t('help')}
      </div>
      <div className="login__container">
        <img width="168px" height="48px" src={logo} alt="deep ai logo" />
      </div>
      <div className="login__text">{t('login_request')}</div>
      <button className="login__button" onClick={props.login}>
        {t('login')}
      </button>
      {props.loggedUser && props.loggedUser.error && (
        <div className="login__alert-text">{props.loggedUser.error}</div>
      )}
    </div>
  );
};
