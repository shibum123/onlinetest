import React from 'react';
import './HomePage.scss';
import Card from '../ui/Card';
import { useTranslation } from 'react-i18next';
import { useHistory } from 'react-router-dom';
import { searchUrl } from '../../constants/constants';

import sper_icon from './../../assets/sper_icon.png';
import search_icon from './../../assets/search_icon.png';

const HomePage = () => {

  const history = useHistory();
  const { t } = useTranslation();

  const onClick = (path) => {
    if (path === './search') {
      window.location.href = searchUrl;
    } else {
      history.push({
        pathname: path
      })
    }
  }
  return <div className="homepage">
    <div className="homepage__elements">
      <label className="homepage__elements__title">{t('general.deep_ai_title')}</label>
      <div className="homepage__cards_container">
        <Card onClick={() => onClick('./submissions')} title={t('general.submission_title')} icon={sper_icon} />
        <Card onClick={() => onClick('./ocr')} title={t('general.ocr_title')} icon={sper_icon}  disabledclass='card-disabled'/>
        <Card onClick={() => onClick('./search')} title={t('general.search_title')} icon={search_icon} />
        <Card onClick={() => onClick('./ocrui')} title={t('general.ocr_ui_title')} icon={sper_icon} /></div>
    </div>
  </div>;
};

export default HomePage;
