if [ -z "${API_BASE_URL}" ]; then
 echo "Environment variable API_BASE_URL is not set but required! Aborting."
 exit 1
fi

for f in /usr/share/nginx/html/static/js/main.*.chunk.js; do
    sed -i -e "s|API_BASE_URL_REPLACE_HERE__PLACEHOLDER|$API_BASE_URL|g" "$f"
done

for f in /usr/share/nginx/html/static/js/main.*.chunk.js; do
    sed -i -e "s|APP_REDIRECT_URI_REPLACE_HERE__PLACEHOLDER|$APP_REDIRECT_URI|g" "$f"
done

nginx -g 'daemon off;'