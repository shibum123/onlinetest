import React, { useReducer, useEffect, useState } from 'react';
import './App.scss';
import SearchOverview from './components/searchoverview/SearchOverview';
import { Home } from './components/home/Home';
import { Login } from './components/login/Login';
import { NotFound } from './components/notfound/NotFound';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import AuthService from './services/auth.service';

export const SearchContext = React.createContext();

const initialState = {
  typedString: '',
  hideModal: false,
  selectedItemChange: null,
};
const reducer = (state, action) => {
  if (action && action.type) {
    switch (action.type) {
      case 'SET_TYPED_STRING':
        return { ...state, typedString: action.value };
      case 'HIDE_MODAL':
        return { ...state, hideModal: true };
      case 'SELECTED_ITEM_CHANGE':
        return { ...state, selectedItemChange: action.value };
      case 'reset':
        return initialState;
      default:
        return state;
    }
  } else {
    return state;
  }
};

const App = () => {
  const enableLogin = false;
  const [typedString, dispatch] = useReducer(reducer, initialState);
  const authService = new AuthService();
  const loggedUser = enableLogin
    ? authService.getUserDetails()
    : { isLogged: true };
  const [isLoggedIn, setisLoggedIn] = useState(loggedUser.isLogged);

  const login = (event) => {
    if (event) {
      event.preventDefault();
    }
    authService.login();
  };
  const logout = () => {
    authService.logout();
  };
  return (
    <SearchContext.Provider
      value={{ searchState: typedString, searchDispatch: dispatch }}>
      <Router>
        <Switch>
          <Route exact path="/">
            {!isLoggedIn && enableLogin && (
              <Login login={login} logout={logout} loggedUser={loggedUser} />
            )}
            {(!enableLogin || isLoggedIn) && (
              <Home
                enableLogin={enableLogin}
                login={login}
                logout={logout}
                loggedUser={loggedUser}
              />
            )}
          </Route>
          <Route path="/search">
            {!isLoggedIn && enableLogin && (
              <Login login={login} logout={logout} loggedUser={loggedUser} />
            )}
            {(!enableLogin || isLoggedIn) && (
              <SearchOverview
                enableLogin={enableLogin}
                login={login}
                logout={logout}
                loggedUser={loggedUser}
                authService={authService}
              />
            )}
          </Route>
          <Route path="/semantic">
            {!isLoggedIn && enableLogin && (
              <Login login={login} logout={logout} loggedUser={loggedUser} />
            )}
            {(!enableLogin || isLoggedIn) && (
              <SearchOverview
                enableLogin={enableLogin}
                login={login}
                logout={logout}
                loggedUser={loggedUser}
                authService={authService}
              />
            )}
          </Route>
          <Route>
            <NotFound />
          </Route>
        </Switch>
      </Router>
    </SearchContext.Provider>
  );
};
export default App;
