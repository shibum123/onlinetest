import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { setEditSubmission, setShowPartyDialog } from './../../redux/ducks/submissions';
import { COMPLETED, PENDING, DELAY, MAX_DELAY, VIEW_REPORT, EDIT_SUBMISSION, SET_PRIMARY_PARTY, NEW_SUBMISSION } from './../../constants/constants';

import moment from 'moment';
import Icon from '@axaxl-web/icon';
import Select from '@axaxl-web/select';
import Menu from '@material-ui/core/menu';
import MenuItem from '@axaxl-web/menu-item';
import Container from '@axaxl-web/container';
import DataTable from '@axaxl-web/data-table';
import Link from '@axaxl-web/link';
import LinearProgress from '@axaxl-web/linear-progress';

import { withStyles } from '@material-ui/core/styles';

import './SubmissionItems.scss';


const StyledMenu = withStyles({
    paper: {
        border: '1px solid #d3d4d5',
    },
})((props) => (
    <Menu
        elevation={0}
        getContentAnchorEl={null}
        anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'center',
        }}
        transformOrigin={{
            vertical: 'top',
            horizontal: 'center',
        }}
        {...props}
    />
));

const StyledMenuItem = withStyles((theme) => ({
    root: {
        '&:focus': {
            backgroundColor: theme.palette.primary.main,
            '& .MuiListItemIcon-root, & .MuiListItemText-primary': {
                color: theme.palette.common.white,
            },
        },
    },
}))(MenuItem);

const SubmissionItems = (props) => {
    const { t } = useTranslation();
    const dispatch = useDispatch();

    const { submissions } = useSelector(state => state.submissions);
    const isOCR = window.location.pathname === '/ocr';
    let headerRow;
    if (isOCR) {
        headerRow = { name: t('submission_items.name'), submittedOn: t('submission_items.submitted_on'), files: t('submission_items.files'), more: '' };
    } else {
        headerRow = { name: t('submission_items.name'), submittedOn: t('submission_items.submitted_on'), files: t('submission_items.files'), primaryParty: t('submission_items.primary_party'), dunsNumber: t('submission_items.duns_number'), clientReportUrl: t('submission_items.client_report_url'), more: '' };
    }
    let data = [];
    const [pollingDelay, setPollingDelay] = useState(DELAY);

    const [anchorEl, setAnchorEl] = useState(null);
    const [isMoreClicked, setIsMoreClicked] = useState(false);
    const [currentSelection, setCurrentSelection] = React.useState([]);

    useEffect(() => {
        const interval = setInterval(() => getProcessingStatus(), pollingDelay);
        return () => clearInterval(interval);
    }, [submissions, pollingDelay]); // eslint-disable-line

    if (submissions) {
        data = submissions.sort((a, b) => new Date(b['submittedTime'] * 1000) - new Date(a['submittedTime']) * 1000).map(item => {
            const currentTime = moment();
            let submissionTime = moment(new Date(item['submittedTime'] * 1000));
            let submittedTime;
            if ((currentTime.diff(submissionTime, 'h')) > 20) {
                submittedTime = submissionTime.format('MMM DD YYYY');
            } else {
                submittedTime = submissionTime.fromNow();
            }

            let reportLink = null;
            let dunsNumber = null;
            let companyName = null;

            if (item['report'] && item['report'].companies) {
                item['report'].companies.forEach(company => {
                    if (item['report'].primary === company.id) {
                        reportLink = company.reportLink;
                        dunsNumber = company.dunsNumber;
                        companyName = company.companyName
                    }
                })
            }

            let files;
            if (Array.isArray(item['files'])) {
                if (item['files'].length === 1) {
                    files = item['files'].length + ` file ` + Array(2).fill('\xa0').join('');
                } else if (item['files'].length < 10) {
                    files = item['files'].length + ` files` + Array(2).fill('\xa0').join('');
                } else {
                    files = item['files'].length + ` files` + Array(1).fill('\xa0').join('');
                }
            } else {
                files = `0 file`
            }

            return item['id'] ? {
                key: item['id'],
                id: item['id'],
                name: item['name'],
                submittedOn: item['submittedTime'] ? submittedTime : ' ',
                files: files,
                fileArray: item['files'],
                processingProgress: item['processingProgress'],
                submissionStatus: item['processingStatus'],
                primaryParty: item['primaryParty'],
                companyName: companyName,
                report: item['report'],
                dunsNumber: dunsNumber,
                clearanceStatus: item['clearanceStatus'],
                clientReportUrl: reportLink,
                submissionIdocUrl: item['submissionIdocUrl'],
                more: reportLink
            }
                : [];
        })
    }

    const getProcessingStatus = () => {
        const _arr = [];
        submissions.forEach(submission => {
            if (submission.processingStatus === PENDING && submission.processingProgress !== 100) {
                _arr.push(submission.id)
            }
        });
        if (_arr.length === 0) return;
        props.allSubmissions.getProcessingStatus(_arr)
            .then((resps) => {
                if (resps && resps.length > 0) {
                    setPollingDelay(DELAY)
                    const processingCompletedIds = [];
                    resps.forEach((resp, index) => {
                        if (resp.data && (resp.data.processingProgress === 100 || resp.data.processingProgress === "100")) {
                            processingCompletedIds.push(_arr[index]);
                        }
                    })

                    if (processingCompletedIds.length > 0) {
                        props.dispatchSubmissions();

                    }
                } else {
                    setPollingDelay(pollingDelay < MAX_DELAY ? pollingDelay + 1000 : MAX_DELAY);
                }
            })
    }

    const getFiles = (row) => {
        if (row['fileArray'].length === 0) return null;
        return row['fileArray'].map((file, index) => {
            return <span key={file.id + index}>{file.fileName}<br /></span>
        })
    }

    const handleClick = (event, isMoreClick, files) => {
        setIsMoreClicked(isMoreClick);
        if (!isMoreClick) {
            setCurrentSelection(files)
        }
        setAnchorEl(event.currentTarget);
    };

    const onFileDownload = (selectedFileIds) => {
        props.allSubmissions.downloadSubmissionFile(selectedFileIds)
            .then(data => {
                b64toBlob(data);
            })
    }

    const onFileView = (selectedFileIds) => {
        // alert('file view')
    }

    const b64toBlob = async (imageDataUrls) => {
        const fileArray = [];
        if (imageDataUrls && imageDataUrls.length > 0) {
            imageDataUrls.forEach((imageDataUrl, index) => {
                fetch(`data: ${imageDataUrl.fileType}; base64, ${imageDataUrl.data} `).then(res => {
                    res.arrayBuffer().then(buf => {
                        const tmpFile = new File([buf], imageDataUrl.filename, { type: imageDataUrl.fileType });
                        tmpFile.id = imageDataUrl.id;
                        fileArray.push(tmpFile);

                        const link = document.createElement('a');
                        const file_name = imageDataUrl.filename;

                        link.href = `data: ${imageDataUrl.fileType}; base64, ${imageDataUrl.data} `;
                        link.title = file_name;
                        link.setAttribute('download', imageDataUrl.filename);
                        document.body.appendChild(link);
                        link.click();
                    })
                })
            })
        }
    };

    const onMoreClick = (name, row) => {
        switch (name) {
            case VIEW_REPORT:
                window.open(row['more'], '_newtab');
                break;
            case EDIT_SUBMISSION:
                dispatch(setEditSubmission(true, row, row['fileArray']))
                break;
            case SET_PRIMARY_PARTY:
                dispatch(setShowPartyDialog(true, row['id']));
                break;
            case NEW_SUBMISSION:
                props.onNewSubmission();
                break;
            default:
        }
        handleClose(null);
    }

    const renderStyledMenuItem = (row, isView) => {
        if (!isMoreClicked && isView) {
            return currentSelection.map(file => <StyledMenuItem ><span onClick={() => onFileView([file])} >{file.fileName}</span></StyledMenuItem>)
        } else if (!isMoreClicked) {
            return currentSelection.map(file => <StyledMenuItem ><span onClick={() => onFileDownload([file])} >{file.fileName}</span></StyledMenuItem>)
        } else {
            if (isOCR) {
                return [
                    {
                        title: EDIT_SUBMISSION,
                        text: 'Edit Submission'
                    },
                    {
                        title: NEW_SUBMISSION,
                        text: 'New Submission'
                    }].map(item =>
                        <StyledMenuItem >
                            <span onClick={() => onMoreClick(item.title, row)} >{item.text}</span>
                        </StyledMenuItem>)
            } else {
                return [
                    {
                        title: VIEW_REPORT,
                        text: 'View Report'
                    },
                    {
                        title: EDIT_SUBMISSION,
                        text: 'Edit Submission'
                    },
                    {
                        title: SET_PRIMARY_PARTY,
                        text: 'Set Primary Party'
                    },
                    {
                        title: NEW_SUBMISSION,
                        text: 'New Submission'
                    }].map(item =>
                        <StyledMenuItem >
                            <span onClick={() => onMoreClick(item.title, row)} >{item.text}</span>
                        </StyledMenuItem>)

            }
        }
    }

    const handleClose = () => {
        setAnchorEl(null);
    };

    const cellFormatters = {
        name: (row, col) => {
            return <div className="submissionItems__id-cell" onClick={() => { dispatch(setEditSubmission(true, row, row['fileArray'])) }} ><span>{row[col]}</span><span>&nbsp;&nbsp;</span><Icon className="fa fa-pencil"></Icon></div >;
        },
        files: (row, col) => {
            const val = getFiles(row)
            if (!val) return row[col];
            return <span className="submissionItems__tooltip">
                <span className="submissionItems__files-col">
                    {
                        row[col]
                    }
                </span>&nbsp;&nbsp;&nbsp;
                <Link className="submissionItems__link" onClick={(event) =>
                    handleClick(event, false, row['fileArray'])}>
                    DOWNLOAD
                </Link>
                <StyledMenu
                    id={`customized-menu${row['id']} `}
                    anchorEl={anchorEl}
                    open={Boolean(anchorEl)}
                    onClose={handleClose} >
                    {
                        renderStyledMenuItem(null, false)
                    }
                </StyledMenu>
                { isOCR && <StyledMenu
                    id={`customized-menu${row['id']} `}
                    anchorEl={anchorEl}
                    open={Boolean(anchorEl)}
                    onClose={handleClose} >
                    {
                        renderStyledMenuItem(null, true)
                    }
                </StyledMenu> }
            </span>
        },
        more: (row, col) => {
            return <span><Icon className="fa fa-1x fa-ellipsis-v submissionItems__vertical-icon" onClick={(event) => handleClick(event, true, null)}
            ></Icon>
                <StyledMenu
                    id={`customized-more-menu${row['id']} `}
                    name={`customized-more-menu`}
                    anchorEl={anchorEl}
                    open={Boolean(anchorEl)}
                    onClose={handleClose} >
                    {
                        renderStyledMenuItem(row)
                    }
                </StyledMenu></span>
        },
        primaryParty: (row, col) => {
            if (row['submissionStatus'] === PENDING) {
                const progress = row['processingProgress'] || 0;
                return <div className="submissionItems__liner-progress"
                ><LinearProgress
                        color='primary'
                        value={progress}
                        variant='determinate'
                    /></div>
            } else if (row['submissionStatus'] === COMPLETED) {
                let primaryParty = null;

                if (row['report']) {
                    primaryParty = row['companyName'];
                }
                return <Select className="submissionItems__select" value={primaryParty || 'Select'} disabled onClick={() => dispatch(setShowPartyDialog(true, row['id']))}>
                    <MenuItem value={primaryParty}>{primaryParty}</MenuItem>
                </Select>
            } else {
                return <span className="submissionItems__status">{row['submissionStatus']}</span>;
            }

        },
        clientReportUrl: (row, col) => {
            return row[col] ? <Link href={row[col]} target="_blank" rel="noopener noreferrer" className="submissionItems__link">{t('submission_items.view_idoc')}</Link> : null
        },
        submissionIdocUrl: (row, col) => {
            return row[col] ? <Link href={row[col]} target="_blank" rel="noopener noreferrer" className="submissionItems__link">{t('submission_items.link_to_doc')}</Link> : null
        },
        clearanceStatus: (row, col) => {
            return row[col] && row[col].toLowerCase() === 'cleared' ? <div className="submissionItems__cleared"><span></span><div>{row[col]}</div></div> : <div className="submissionItems__cleared submissionItems__cleared-not"><span></span><div>Not Cleared</div></div>
        }
    };

    return <Container className="submissionItems">
        <DataTable
            variant="sortable"
            headers={headerRow}
            defaultRowDisplay={10}
            cellFormatters={cellFormatters}
            data={data}
        />
    </Container>
}

export default SubmissionItems;
