import React from 'react';
import { Home } from './Home';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';

jest.mock('react-router-dom', () => {
  return {
    ...jest.requireActual('react-router-dom'),
    useLocation: () => ({
      pathname: '/search',
    }),
  };
});

const wrapper = shallow(<Home />);

describe('home component', () => {
  it('should render correctly', () => {
    expect(wrapper.exists()).toBe(true);
  });

  it('should match the snapshot', () => {
    expect(wrapper).toMatchSnapshot(true);

    const loggedUser = {
      name: 'Shibu Manoharan',
    };

    let tree = renderer
      .create(<Home enableLogin={true} loggedUser={loggedUser} />)
      .toJSON();
    expect(tree).toMatchSnapshot();
  });
});
