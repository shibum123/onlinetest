import React from 'react';
import './Card.scss';
import Button from '@axaxl-web/button';
import { useTranslation } from 'react-i18next';

const Card = (props) => {
    const { t } = useTranslation();

    return <div className={`card ${props.disabledclass}`} onClick={() => props.onClick()}>
        <div className="card__content">
            <img src={props.icon} alt={props.title} className="card__img" /><br />
            <div className="card__title-container">
                <label className="card__title-text">{props.title}</label>
            </div>
            <br /><br />
            <Button className="card__button">{t('buttons.launch')}</Button>
        </div></div>
}

export default Card;