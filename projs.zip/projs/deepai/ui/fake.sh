#!/bin/bash

GREEN='\033[1;32m'
NC='\033[0m' # No Color

if [[ $1 == '--help' ]]
then

    echo "${GREEN}"
    echo "=================================================================================="
    echo ""
    echo "fake.sh"
    echo ""
    echo "Description:"
    echo ""
    echo "    Serves a fake API with mock-server to"
    echo "    a) get around needing an Authorization Server (by mocking /api/user)"
    echo "    b) get around needing a backend API (by letting you hit endpoints directly)"
    echo ""
    echo "    Note: To simulate a logged-out user, set user.preferred_username='' in db.json"
    echo ""
    echo "Usage:" 
    echo ""
    echo "    sh fake.sh [PORT:8080]"
    echo ""
    echo "Examples:"
    echo ""
    echo "    sh fake.sh"
    echo "    => runs on the default port 8080 in place of the proxy"
    echo ""
    echo "    sh fake.sh 8081"
    echo "    => runs on port 8081 behind the proxy to simulate the API gateway"
    echo "=================================================================================="
    echo ""
    echo "${NC}"
else

    set -e

    #check if java installed and use it? too risky?
    if ! [[ -n `which java` ]]; then
        echo "\n${GREEN}Try installing SDKMAN, if necessary...${NC}\n"
        curl -s "https://get.sdkman.io" | bash
        source "$HOME/.sdkman/bin/sdkman-init.sh"
        echo "\n${GREEN}Installing Default JDK, if necessary...${NC}\n"
        sdk install java || true
    fi

    if ! [[ -n `which java` ]]; then
        echo "\n${RED}Java is still not installed/setup. Can't continue until that is complete.${NC}\n"
        exit 1
    fi

    [ $1 ] && port=$1 || port=8080
    java -Dmockserver.watchInitializationJson=true -Dmockserver.initializationJsonPath=mockData.json -jar node_modules/mockserver-node/mockserver-netty-*-jar-with-dependencies.jar -serverPort $port

fi

