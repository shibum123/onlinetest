import React, { useEffect, useState } from 'react';
import Typography from '@axaxl-web/typography';
import TextField from '@axaxl-web/text-field';
import Button from '@axaxl-web/button';
import Link from '@axaxl-web/link';
import Icon from '@axaxl-web/icon';

import { useTranslation } from 'react-i18next';
import { DropzoneArea } from 'material-ui-dropzone';
import { useDispatch, useSelector } from 'react-redux';
import { setSnackbar } from '../../redux/ducks/general';
import { setFiles } from '../../redux/ducks/submissions';
import { Submissions } from './Submissions';
// import { CLEARED } from './../../constants/constants';

import './NewSubmission.scss';

const NewSubmission = (props) => {
    const { t } = useTranslation();
    const { selectedFileIds, submission } = useSelector(state => state.submissions)
    const { files } = useSelector(state => state.submissions);

    const [allFiles, setAllFiles] = useState([]);
    const [name, setName] = useState('');

    const submissions = new Submissions();
    const dispatch = useDispatch();

    useEffect(() => {
        const elem = document.getElementsByClassName('MuiDropzoneArea-textContainer');

        const fileIcon = document.getElementById('newsubmission__button-submit-hidden');
        const clone = fileIcon.cloneNode(true);
        clone.id = `button-submit-visible`;

        const pTag = document.createElement('center');
        pTag.appendChild(clone)
        clone.classList.add("newsubmission__button-submit-visible");
        if (!document.getElementById('button-submit-visible')) {
            elem[0].appendChild(pTag);
        }
    });

    useEffect(() => {
        submissions.downloadSubmissionFile(selectedFileIds)
            .then(data => {
                b64toBlob(data);
            })
    }, [selectedFileIds, b64toBlob]); // eslint-disable-line

    useEffect(() => {
        setName(submission.name);
    }, [submission]);

    const b64toBlob = async (imageDataUrls) => {
        const fileArray = [];
        if (imageDataUrls && imageDataUrls.length > 0) {
            imageDataUrls.forEach((imageDataUrl, index) => {
                fetch(`data:${imageDataUrl.fileType};base64,${imageDataUrl.data}`).then(res => {
                    res.arrayBuffer().then(buf => {
                        const tmpFile = new File([buf], imageDataUrl.filename, { type: imageDataUrl.fileType });
                        tmpFile.id = imageDataUrl.id;
                        fileArray.push(tmpFile);
                        if (index === imageDataUrls.length - 1) {
                            dispatch(setFiles(fileArray));
                        }
                    })
                })

                // TODO: To remove
                /* const link = document.createElement('a');
                const file_name = imageDataUrl.filename;
                const _index = file_name.lastIndexOf('.'); */

                /* let file_part = file_name;
                let extension_part;

                if (_index > 0) {
                    file_part = file_name.substring(0, _index);
                    extension_part = file_name.substring(_index, file_name.length);
                } */

                /* const _text = _index > 10 ? `${file_part.substring(0, 10)}...${extension_part}` : file_name;

                link.href = `data:${imageDataUrl.fileType};base64,${imageDataUrl.data}`;
                link.title = file_name;
                link.setAttribute('download', imageDataUrl.filename);

                const _div = document.createElement('div');

                const _div2 = document.createElement('div');
                _div2.setAttribute('class', 'newsubmission__file_container');
                _div.appendChild(_div2);

                const _icon = document.createElement('i');

                _icon.setAttribute('class', 'fa fa-file-o fa-4x newsubmission__file');
                _div2.appendChild(_icon);

                const label = document.createElement('label');

                label.append(_text);
                _div.appendChild(label); */

                /*  const _icon2 = document.createElement('i');
                 _icon2.setAttribute('color', 'primary');
                 _icon2.setAttribute('name', 'close');
                 _icon2.setAttribute('class', 'fa fa-close newsubmission__close');
                 _div.appendChild(_icon2); */

                /* link.appendChild(_div); */

                // document.getElementById('downloads').appendChild(link);
                const span = document.createElement('span');
                span.append(' ');
                document.getElementById('downloads').appendChild(span);
            })
        }
    };

    const findRemoved = () => {
        const removed = [];
        const files_arr = allFiles.map(file => {
            return file.id;
        });
        files.forEach(file => {
            if (file.id && files_arr.indexOf(file.id) < 0) {
                removed.push(file.id)
            }
        });
        return removed;
    }

    const onSubmit = async (isDraft = true) => {
        const result = [];
        if (allFiles && allFiles.length === 0) {
            props.onSubmit({ name: name, files: [], isDraft: isDraft, removed: findRemoved() })
        } else if (allFiles && allFiles.length > 0) {
            let _index = 0;
            const removed = findRemoved();
            allFiles.forEach(file => {
                const reader = new FileReader();
                reader.readAsDataURL(file);
                reader.onload = function () {
                    result.push({
                        id: file.id,
                        fileName: file.name,
                        fileType: file.type,
                        fileContent: reader.result
                    });
                    if (++_index === allFiles.length) {
                        props.onSubmit({ name: name, files: result, isDraft: isDraft, removed: removed })
                    }
                };
                reader.onerror = function (error) {
                    dispatch(setSnackbar(true, 'error', t('error.data_load_error')));
                };
            })
        }
    }

    const handleChange = async (loadedFiles) => {
        setAllFiles(loadedFiles);
    }

    // TODO: Waiting for updated API
    const isCleared = false // submission && submission.clearanceStatus && (submission.clearanceStatus.toLowerCase() === CLEARED)

    return <div className="newsubmission">
        <Button id="newsubmission__button-submit-hidden" className="newsubmission__button-submit-visible" onClick={() => onSubmit(false)}>{t('buttons.upload_file')}</Button>
        <div className="newsubmission__title_container">
            <Typography variant="moduleTitle" className="newsubmission__title" >{t('submission.new_submission_title')}</Typography>
            <Icon fontSize="medium" color="primary" name="close" className="newsubmission__close" onClick={props.handleOnClose} />
        </div>
        <div className="newsubmission__inline">
            <Typography variant="textStandard" className="newsubmission__inline-text">{t('submission.submission_name')}</Typography>
            {submission.name === null && <TextField id="submission-name" className="newsubmission__inline-input" placeholder={t('submission.submission_name_placeholder')} onChange={(event) => setName(event.target.value)} required />}
            {submission.name !== null && <TextField id="submission-name" className="newsubmission__inline-input" placeholder={t('submission.submission_name_placeholder')} onChange={(event) => setName(event.target.value)} value={submission.name} disabled />}
        </div>
        <div className="newsubmission__dropzonecontainer">
            {files.length !== 0 && <DropzoneArea id="submission-docupload"
                onChange={handleChange}
                showFileNamesInPreview={true}
                showPreviews={true}
                showPreviewsInDropzone={false}
                zeroMinWidth={true}
                previewGridProps={{ item: { spacing: 10, direction: 'row' } }}
                dropzoneText={t('submission.drop_files')}
                filesLimit={30}
                initialFiles={files}
                fullWidth={false}
            />}
            {files.length === 0 && <DropzoneArea id="submission-docupload"
                onChange={handleChange}
                dropzoneText={t('submission.drop_files')}
                filesLimit={30}
            />}
        </div>
        <div id="downloads" className="newsubmission__download_links"></div>
        <div className="newsubmission__button-container">
            {!isCleared && name && name.trim() !== '' && <><Link rel="noopener noreferrer" className="newsubmission__link" onClick={onSubmit}>{t('buttons.save_draft')}</Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</>}
            {(isCleared || !(name && name.trim() !== '')) && <><Link className="newsubmission__button newsubmission__button-disabled" disabled >{t('buttons.save_draft')}</Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</>}
            {!isCleared && submission.id && <><Link rel="noopener noreferrer" className="newsubmission__link" onClick={() => props.deleteSubmission(submission.id)}>{t('buttons.delete')}</Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</>}
            <Button className="newsubmission__button" onClick={props.handleOnClose} color="secondary">{t('buttons.cancel')}</Button>&nbsp;&nbsp;&nbsp;
            {!isCleared && name && name.trim() !== '' && <Button className="newsubmission__button" onClick={() => onSubmit(false)}>{t('buttons.submit')}</Button>}
            {(isCleared || !(name && name.trim() !== '')) && <Button className="newsubmission__button newsubmission__button-disabled" disabled >{t('buttons.submit')}</Button>}
        </div>
    </div>
}

export default NewSubmission;