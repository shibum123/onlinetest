import React, { useState, useEffect, createRef, useContext } from 'react';
import './SearchOverview.scss';
import { ListItem } from '../ui/ListItem';
import moment from 'moment';
import { useTranslation } from 'react-i18next';
import {
  BASE_URL,
  DOC_SOURCE,
  INDEX_NAME,
  PAGE_SIZE,
  CONTENT_LENGTH,
  ENABLED_DOC_TYPES,
  ENABLE_FACETED_SEARCH,
} from '../../config';
import { Pagination } from '../pagination/Pagination';
import { Ripple } from 'react-awesome-spinners';
import { SearchHeader } from '../searchheader/SearchHeader';
import { useLocation } from 'react-router-dom';
import { useHistory } from 'react-router-dom';
import { SearchInput } from '../ui/SearchInput';
import normalView from '../../assets/normalview.png';
import detailedView from '../../assets/detailedview.png';
import normalViewDisabled from '../../assets/normalview-disabled.png';
import detailedViewDisabled from '../../assets/detailedview-disabled.png';
import { SearchContext } from '../../App';
import { DetailedView } from '../detailedview/DetailedView';
import { PDF_TYPE, EXCEL_TYPE, DOC_TYPE } from '../../utils/AppConstants';
import decodeJWT from 'jwt-decode';
import { ErrorBoundary } from '../ui/ErrorBoundary';
import SearchService from '../../services/SearchService';
// import Select from 'react-select';

const SearchOverview = (props) => {
  const location = useLocation();
  const [dataList, setDataList] = useState([]);
  const [activePage, setActivePage] = useState(1);
  const [dataUpdateToggle, setDataUpdateToggle] = useState(false);
  const [paginationData, setPaginationData] = useState([]);
  const [allPageData, setAllPageData] = useState([]);
  const [totalPages, setTotalPages] = useState(1);
  const [searchString, setSearchString] = useState('');
  const [selectedDoc, setSelectedDoc] = useState({});
  const [searchType, setSearchType] = useState('keyword');
  const [searchedData, setSearchedData] = useState({});
  // const [facetedSearch, setFacetedSearch] = useState(null);
  // const [filteredData, setFilteredData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDetailedView, setIsDetailedView] = useState(false);
  const [accessToken, setAccessToken] = useState(
    props.loggedUser ? props.loggedUser.access_token : null,
  );
  // const [options, setOptions] = useState([]);
  const history = useHistory();
  const { t } = useTranslation();

  const [searchLoc, setSearchLoc] = useState({
    content: true,
    filename: false,
    title: false,
  });
  const [pdfType, setPdfType] = useState(true);
  const [docType, setDocType] = useState(false);
  const [excelType, setExcelType] = useState(false);

  const [fileName, setFileName] = useState(false);
  const [keyWordSearch, setKeyWordSearch] = useState(
    location.pathname === '/search',
  );
  const [title, setTitle] = useState(false);

  const [documentType, setDocumentType] = useState([PDF_TYPE]);

  const [dateRange, setDateRange] = useState({
    startDate: '1900-01-01 00:00:00',
    endDate: '2200-01-01 00:00:00',
  });

  const useAuthToken = false;

  const inputField = createRef();

  const startDateRef = React.useRef();
  const endDateRef = React.useRef();

  const searchContext = useContext(SearchContext);
  // const [selectedValue, setSelectedValue] = useState([]);

  /* const handleChange = (value, { action, removedValue }) => {
    switch (action) {
      case 'remove-value':
      case 'pop-value':
        if (removedValue && removedValue.isFixed) {
          return;
        }
        break;
      case 'clear':
        value = options.filter((v) => v.isFixed);
        break;
    }
    setSelectedValue(value);

    let val = [];
    if (value) {
      val = value.map((item) => item.value.trim().toLowerCase());
      setFacetedSearch(val);
    } else {
      setFacetedSearch(null);
    }
    handleResultsData(filteredData, val);
  }; */

  useEffect(() => {
    setIsLoading(false);
    if (searchString.trim() !== '') {
      searchData(searchString);
    }
  }, [dataUpdateToggle, searchString]);

  const submitForm = () => {
    if (sessionStorage.getItem('searchKey') !== null) {
      const pay_load = sessionStorage.getItem('searchKey');
      sessionStorage.removeItem('searchKey');
      getSearchData(pay_load);
      return;
    }
    let search_type =
      location.pathname === '/semantic' ||
      location.pathname === '/semantic-advanced'
        ? 'semantic'
        : 'keyword';
    setSearchType(search_type);
    if (
      location.state &&
      !location.state.advancedSearch &&
      !location.state.searchText
    ) {
      setActivePage(1);
      setDataList([]);
    } else if (
      location.pathname === '/semantic' ||
      location.pathname === '/search'
    ) {
      if (location.state && location.state.searchText) {
        searchContext.searchDispatch({
          type: 'SET_TYPED_STRING',
          value: location.state.searchText,
        });
        setDataUpdateToggle(!dataUpdateToggle);
        setSearchString(location.state.searchText);
        setDisabled(false);
      }
    }
  };

  useEffect(() => {
    submitForm();
  }, [location]);

  const [disabled, setDisabled] = useState(true);

  const handleOnChange = (event) => {
    searchContext.searchDispatch({
      type: 'SET_TYPED_STRING',
      value: event.target.value,
    });
    setDisabled(event.target.value ? event.target.value.trim() === '' : true);
  };

  const showDetailedView = (event, currentItem) => {
    event.preventDefault();
    setSelectedDoc(currentItem);

    searchContext.searchDispatch({
      type: 'SELECTED_ITEM_CHANGE',
      value: currentItem,
    });

    setIsDetailedView(true);
  };

  const showItem = (event) => {
    event.currentTarget.children[0].style.display = 'none';
    event.currentTarget.children[1].style.display = 'block';
  };

  const hideItem = (event) => {
    event.currentTarget.children[0].style.display = 'block';
    event.currentTarget.children[1].style.display = 'none';
  };

  const handlePageChange = (pageNumber) => {
    if (pageNumber < 1 || pageNumber > totalPages) return;
    setActivePage(pageNumber);
    setDataList(allPageData[pageNumber - 1]);

    const arr = paginationData.map((element, index) => {
      element.isActive = index === pageNumber - 1 ? 'active' : '';
      return element;
    });

    setPaginationData(arr);
  };

  const searchData = (payload = '') => {
    if (useAuthToken && accessToken) {
      if (Date.now() >= decodeJWT(accessToken).exp * 1000) {
        sessionStorage.setItem('searchKey', payload);
        props.authService.refreshToken().then((resp) => {
          if (resp === null) {
            props.login();
            return;
          }
          setAccessToken(resp.access_token);
          getSearchData(payload, resp.access_token);
        });
      } else {
        getSearchData(payload);
      }
    } else if (useAuthToken) {
      props.login();
    } else {
      getSearchData(payload);
    }
  };

  // TODO: service module
  /* istanbul ignore next */
  const getSearchData = async (payload = '', access_token = '') => {
    sessionStorage.removeItem('searchKey');
    let baseURL = BASE_URL;

    setSearchString(payload);

    let search_type =
      searchType === 'semantic' || searchType === 'semantic-advanced'
        ? 'semantic'
        : 'keyword';
    let no_semantic_results =
      searchType === 'semantic' || searchType === 'semantic-advanced'
        ? 10
        : 250;

    const otherFields = ['content'];
    if (fileName === true) {
      otherFields.push('filename');
    }

    if (title === true) {
      otherFields.push('title');
    }

    const docTypes = [];

    if (pdfType === true) {
      docTypes.push(PDF_TYPE);
    }

    if (excelType === true) {
      docTypes.push(EXCEL_TYPE);
    }

    if (docType === true) {
      docTypes.push(DOC_TYPE);
    }

    const data = {
      search_term: `${payload}`,
      search_type: search_type,
      document_source: `${DOC_SOURCE}`,
      email: '***',
      other_fields: otherFields,
      startdate: dateRange.startDate
        ? dateRange.startDate
        : '1900-01-01 00:00:00',
      enddate: dateRange.endDate ? dateRange.endDate : '2200-01-01 00:00:00',
      document_type: docTypes,
      no_semantic_results: no_semantic_results,
      content_length: CONTENT_LENGTH,
      index_name: INDEX_NAME,
    };

    setIsLoading(true);

    setSearchedData(data);

    searchContext.searchDispatch({
      type: 'SELECTED_ITEM_CHANGE',
      value: null,
    });

    SearchService.getSearchData(access_token, accessToken, baseURL, data)
      .then((resp) => {
        let result = resp.data ? resp.data : [];
        if (!Array.isArray(result)) {
          result = [];
        }

        const faceted_keywords = [];
        for (let { faceted_keywords: keywords } of result) {
          if (keywords) {
            keywords.split(',').map((item) => {
              faceted_keywords.push(item.trim().toLowerCase());
            });
          }
        }

        /* const uniqueKeywords = faceted_keywords
          ? [...new Set(faceted_keywords)]
          : [];
        const _options = uniqueKeywords.map((item) => {
          return {
            value: item,
            label: item,
          };
        });
        setOptions(_options); */
        // setFilteredData(result);
        // handleResultsData(result, facetedSearch);
        handleResultsData(result, null);
      })
      .catch((error) => {
        setDataList([]);
        setIsLoading(false);
      });
  };

  const handleResultsData = (result, _facetedSearch) => {
    let filtered = [];

    if (ENABLE_FACETED_SEARCH && _facetedSearch && _facetedSearch.length > 0) {
      result.map((item) => {
        if (item.faceted_keywords) {
          let found = false;
          item.faceted_keywords.split(',').map((keyword) => {
            if (
              !found &&
              _facetedSearch.indexOf(keyword.trim().toLowerCase()) > -1
            ) {
              found = true;
              filtered.push(item);
            }
          });
        }
      });
    } else {
      filtered = result;
    }
    let total = Math.ceil(filtered.length / PAGE_SIZE);
    setActivePage(1);
    if (total === 0) {
      setDataList([]);
    } else if (total > 20) {
      total = 20; // TODO: Should be removed and should be showing only 5 at a time
    }
    setTotalPages(total);
    const paginationArr = [];
    let page = -1;
    const pagedData = [];
    for (let index = 0; index < filtered.length; index++) {
      if (index % PAGE_SIZE === 0) {
        page++;
        pagedData[page] = [];
        paginationArr.push({
          label: page + 1,
          isActive: page === 0 ? 'active' : '',
        });
      }
      pagedData[page].push(filtered[index]);
    }
    setAllPageData(pagedData);
    setPaginationData(paginationArr);
    setDataList(pagedData[0]);
    setIsLoading(false);
  };
  const handleMouseClick = () => {
    if (!disabled) {
      history.push({
        pathname:
          document.getElementById('isKeywordSearch').checked === true
            ? '/search'
            : '/semantic',
        state: { searchText: inputField.current.value },
      });
    }
  };
  const handleKeyDown = (evt) => {
    if (evt.key === 'Enter') {
      setActivePage(1);
      setDataUpdateToggle(!dataUpdateToggle);
      setSearchString(evt.target.value);
    }
  };

  const onReset = (evt) => {
    evt.preventDefault();
    setSearchLoc({
      content: true,
      filename: false,
      title: false,
    });
    setPdfType(true);
    setDocType(false);
    setExcelType(false);

    setFileName(false);
    setTitle(false);

    setDocumentType([PDF_TYPE]);

    setDateRange({
      startDate: '1900-01-01 00:00:00',
      endDate: '2200-01-01 00:00:00',
    });

    startDateRef.current.value = '1900-01-01 00:00:00';
    endDateRef.current.value = '2200-01-01 00:00:00';
  };

  const toggleView = (viewName) => {
    if (viewName === 'normal') {
      setIsDetailedView(false);
    } else {
      setIsDetailedView(true);
    }
  };

  const onKeywordSearchChange = (e) => {
    setKeyWordSearch(e.target.checked);
    if (!disabled) {
      handleMouseClick();
    }
  };

  const onSearchLocChange = (e, type) => {
    const locations = searchLoc;
    locations[type] = e.target.checked;
    if (type === 'filename') {
      setFileName(e.target.checked);
    } else if (type === 'title') {
      setTitle(e.target.checked);
    }

    setSearchLoc(locations);
  };
  const onDocTypeChange = (e, type) => {
    const doc_type = documentType.filter((item) => item !== type);

    if (e.target.checked) {
      doc_type.push(type);
    }

    setDocumentType(doc_type);

    if (type === DOC_TYPE) {
      setDocType(e.target.checked);
    } else if (type === PDF_TYPE) {
      setPdfType(e.target.checked);
    } else if (type === EXCEL_TYPE) {
      setExcelType(e.target.checked);
    }
  };
  const onFocusOut = (e, type) => {
    const dateVal = dateRange;
    if (e.target.value !== '' && e.target.value !== null) {
      if (e.target.value < '1900-01-01') {
        e.target.value = '1900-01-01 00:00:00';
        dateVal[type] = e.target.value;
      } else if (e.target.value > '2200-01-01') {
        e.target.value = '2200-01-01 00:00:00';
        dateVal[type] = e.target.value;
      }
      setDateRange(dateVal);
    }
  };
  const onDateRangeChange = (e, type) => {
    const dateVal = dateRange;
    if (e.target.value === '' || e.target.value === null) {
      if (type === 'startDate') {
        dateVal[type] = '1900-01-01 00:00:00';
      } else {
        dateVal[type] = '2200-01-01 00:00:00';
      }
    } else {
      if (type === 'startDate') {
        if (e.target.value > dateVal['endDate']) {
          dateVal['endDate'] = e.target.value + ' 00:00:00';
          dateVal['startDate'] = e.target.value + ' 00:00:00';
          endDateRef.current.value = e.target.value;
          startDateRef.current.value = e.target.value;
        }
      } else {
        if (dateVal['startDate'] > e.target.value) {
          dateVal['endDate'] = e.target.value + ' 00:00:00';
          dateVal['startDate'] = e.target.value + ' 00:00:00';
          endDateRef.current.value = e.target.value;
          startDateRef.current.value = e.target.value;
        }
      }
      dateVal[type] = e.target.value + ' 00:00:00';
    }
    setDateRange(dateVal);
  };

  const body = dataList
    ? dataList.map((item, index) => {
        const currentItem = item._source ? item._source : item;
        const className = index + '' + currentItem.filename;
        return {
          _id: item._id,
          dataListItem: item,
          filename: (
            <span title={currentItem.filename}>{currentItem.filename}</span>
          ),
          category: 'PartyBot',
          create_date: moment(currentItem.create_date).format(
            'MMM DD, YYYY - hh:mm a',
          ),
          content: (
            <span
              title={`${
                currentItem.content ? currentItem.content.substring(0, 50) : ''
              }...`}>
              {currentItem.content ? currentItem.content : ''}
            </span>
          ),
          action: (
            <a
              href="#"
              onClick={(event) => showDetailedView(event, currentItem)}>
              <div
                className="search-overview__right-arrow"
                key={className}
                onMouseOver={showItem}
                onMouseOut={hideItem}>
                <svg
                  className="search-overview__icon-right"
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24">
                  <g data-name="Right Arrow" fill="none">
                    <path
                      d="M23.707,11.294l-11-11A1,1,0,0,0,11,1V6H1A1,1,0,0,0,0,7V17a1,1,0,0,0,1,1H11v5a1,1,0,0,0,.617.924,1,1,0,0,0,1.09-.217l11-11a1,1,0,0,0,0-1.414Z"
                      stroke="none"
                    />
                    <path
                      d="M 11.9998836517334 1.001720428466797 L 11.9998836517334 6.000810623168945 L 11.9998836517334 7.000810623168945 L 10.9998836517334 7.000810623168945 L 1.000003814697266 7.000761032104492 L 0.9999847412109375 17.00027084350586 L 10.9998836517334 17.00027084350586 L 11.9998836517334 17.00027084350586 L 11.9998836517334 18.00027084350586 L 11.99848365783691 22.99967193603516 L 11.99923038482666 22.99998092651367 C 11.99929428100586 22.99993705749512 11.99946880340576 22.99990653991699 11.99977397918701 22.99989128112793 L 22.99966430664063 12.00069141387939 L 11.9998836517334 1.001720428466797 M 11.99930000305176 0 C 12.25966930389404 7.62939453125e-06 12.51551055908203 0.1027202606201172 12.70686435699463 0.2940616607666016 L 23.70675468444824 11.29357147216797 C 24.09774398803711 11.68455123901367 24.09774398803711 12.31652069091797 23.70675468444824 12.70751094818115 L 12.70686435699463 23.70701026916504 C 12.51586437225342 23.89900016784668 12.25987434387207 24.00000190734863 11.99987411499023 24.00000190734863 C 11.87087345123291 24.00000190734863 11.74087429046631 23.97600173950195 11.61688423156738 23.92400169372559 C 11.24388408660889 23.77001190185547 10.9998836517334 23.40403175354004 10.9998836517334 23.00004196166992 L 10.9998836517334 18.00027084350586 L 0.9999847412109375 18.00027084350586 C 0.4479942321777344 18.00027084350586 3.814697265625e-06 17.55329132080078 3.814697265625e-06 17.00031089782715 L 3.814697265625e-06 7.000761032104492 C 3.814697265625e-06 6.447790145874023 0.4479942321777344 6.000810623168945 0.9999847412109375 6.000810623168945 L 10.9998836517334 6.000810623168945 L 10.9998836517334 1.001031875610352 C 10.9998836517334 0.5970516204833984 11.24388408660889 0.2320709228515625 11.61688423156738 0.07707023620605469 C 11.74064922332764 0.02511787414550781 11.87051773071289 -3.814697265625e-06 11.99930000305176 0 Z"
                      stroke="none"
                      fill="#e5e5e5"
                    />
                  </g>
                </svg>
                <svg
                  className="search-overview__icon-right-hover"
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24">
                  <g data-name="Right Arrow hovered" fill="none">
                    <path
                      d="M23.707,11.294l-11-11A1,1,0,0,0,11,1V6H1A1,1,0,0,0,0,7V17a1,1,0,0,0,1,1H11v5a1,1,0,0,0,.617.924,1,1,0,0,0,1.09-.217l11-11a1,1,0,0,0,0-1.414Z"
                      stroke="none"
                    />
                    <path
                      d="M 11.9998836517334 1.001720428466797 L 11.9998836517334 6.000810623168945 L 11.9998836517334 7.000810623168945 L 10.9998836517334 7.000810623168945 L 1.000003814697266 7.000761032104492 L 0.9999847412109375 17.00027084350586 L 10.9998836517334 17.00027084350586 L 11.9998836517334 17.00027084350586 L 11.9998836517334 18.00027084350586 L 11.99848365783691 22.99967193603516 L 11.99923038482666 22.99998092651367 C 11.99929428100586 22.99993705749512 11.99946880340576 22.99990653991699 11.99977397918701 22.99989128112793 L 22.99966430664063 12.00069141387939 L 11.9998836517334 1.001720428466797 M 11.99930000305176 0 C 12.25966930389404 7.62939453125e-06 12.51551055908203 0.1027202606201172 12.70686435699463 0.2940616607666016 L 23.70675468444824 11.29357147216797 C 24.09774398803711 11.68455123901367 24.09774398803711 12.31652069091797 23.70675468444824 12.70751094818115 L 12.70686435699463 23.70701026916504 C 12.51586437225342 23.89900016784668 12.25987434387207 24.00000190734863 11.99987411499023 24.00000190734863 C 11.87087345123291 24.00000190734863 11.74087429046631 23.97600173950195 11.61688423156738 23.92400169372559 C 11.24388408660889 23.77001190185547 10.9998836517334 23.40403175354004 10.9998836517334 23.00004196166992 L 10.9998836517334 18.00027084350586 L 0.9999847412109375 18.00027084350586 C 0.4479942321777344 18.00027084350586 3.814697265625e-06 17.55329132080078 3.814697265625e-06 17.00031089782715 L 3.814697265625e-06 7.000761032104492 C 3.814697265625e-06 6.447790145874023 0.4479942321777344 6.000810623168945 0.9999847412109375 6.000810623168945 L 10.9998836517334 6.000810623168945 L 10.9998836517334 1.001031875610352 C 10.9998836517334 0.5970516204833984 11.24388408660889 0.2320709228515625 11.61688423156738 0.07707023620605469 C 11.74064922332764 0.02511787414550781 11.87051773071289 -3.814697265625e-06 11.99930000305176 0 Z"
                      stroke="none"
                      fill="#00008f"
                    />
                  </g>
                </svg>
              </div>
            </a>
          ),
        };
      })
    : [];

  return (
    <div className="search-overview">
      <SearchHeader
        enableLogin={props.enableLogin}
        login={props.login}
        logout={props.logout}
        loggedUser={props.loggedUser}
        showBrandingLogo={true}
      />
      <div className="search-overview__header">
        <SearchInput
          searchedData={searchedData}
          inputField={inputField}
          handleOnChange={handleOnChange}
          handleKeyDown={handleKeyDown}
          handleMouseClick={handleMouseClick}
        />
        <div className="home__button-container">
          <input
            type="button"
            className="search-overview__button"
            onClick={handleMouseClick}
            value={t('search_button')}
            disabled={disabled}
            tabIndex="2"
          />
          <label
            className="advanced_search__text-aligned container"
            htmlFor="isKeywordSearch">
            &nbsp;&nbsp;&nbsp;{t('exact_match')}
            <input
              type="checkbox"
              id="isKeywordSearch"
              onChange={(e) => onKeywordSearchChange(e)}
              checked={keyWordSearch === true}
            />
            <span className="checkmark"></span>
          </label>
        </div>
        <div className="search-overview__help">
          <div className="search-overview__help-circle">
            <div className="search-overview__help-circle-text">?</div>
            <span className="search-overview__help__tool-tip">
              {t('search_ui')}
            </span>
          </div>
          {t('help')}
        </div>
      </div>

      <div className="search-overview__header-container">
        <br />
        <br />
        <br />
        <div className="search-overview__view-toggle-container">
          <img
            alt="normal view"
            className="search-overview__view-toggle"
            src={isDetailedView ? normalView : normalViewDisabled}
            onClick={() => toggleView('detailed')}
          />
          <img
            alt="detailed view"
            className="search-overview__view-toggle"
            src={isDetailedView ? detailedViewDisabled : detailedView}
            onClick={() => toggleView('normal')}
          />
        </div>
      </div>
      <hr className="search-overview__hr-header" />
      {/* <ShowDocument
        document={selectedDoc}
        searchWords={searchString.split(' ')}
      /> */}
      {isLoading && (
        <div className="loader">
          <Ripple />
        </div>
      )}
      <div className="search-overview__search-table-container">
        <div className="search-overview__search-left-pane">
          {ENABLE_FACETED_SEARCH && (
            <React.Fragment>
              <div className="search-overview__subheading">
                {t('overview_refine_search')}
              </div>
              <input
                type="button"
                className="advanced_search__apply-button"
                data-dismiss="modal"
                onClick={submitForm}
                value={t('overview_apply_button')}
                disabled={disabled}
              />
              &nbsp;&nbsp;&nbsp;
              <a href="#" onClick={onReset}>
                <span className="search-overview__reset-label">
                  {t('overview_reset_button')}
                </span>
              </a>
              <div className="search-overview__left-pane-items">
                {/* <label
                  className="search-overview__label"
                  htmlFor="companySelect">
                  {t('overview_comp_selected')}
                </label>
                <Select
                  value={selectedValue}
                  isMulti
                  isClearable={
                    selectedValue
                      ? selectedValue.some((v) => !v.isFixed)
                      : false
                  }
                  className="Select-control"
                  onChange={handleChange}
                  options={options}
                /> */}
                <label className="advanced_search__label">
                  {t('overview_search_location')}
                </label>
                <div>
                  <label
                    className="advanced_search__text-disabled container"
                    htmlFor="content">
                    &nbsp;&nbsp;{t('overview_content')}
                    <input
                      type="checkbox"
                      id="content"
                      disabled
                      checked
                      onChange={(e) => onSearchLocChange(e, 'content')}
                    />
                    <span className="checkmark"></span>
                  </label>
                </div>
                <div>
                  <label
                    className="advanced_search__text container"
                    htmlFor="filename">
                    &nbsp;&nbsp;{t('overview_filename')}
                    <input
                      type="checkbox"
                      id="filename"
                      checked={fileName === true}
                      onChange={(e) => onSearchLocChange(e, 'filename')}
                    />
                    <span className="checkmark"></span>
                  </label>
                </div>
                <div>
                  <label
                    className="advanced_search__text container"
                    htmlFor="title">
                    &nbsp;&nbsp;{t('overview_title')}
                    <input
                      type="checkbox"
                      id="title"
                      checked={title === true}
                      onChange={(e) => onSearchLocChange(e, 'title')}
                    />
                    <span className="checkmark"></span>
                  </label>
                </div>
                <div>
                  <label className="advanced_search__label">
                    {t('overview_category')}
                  </label>
                  <select
                    id="category"
                    className="advanced_search__select advanced_search__select-disabled"
                    disabled>
                    <option value="submission">
                      {t('overview_submissions')}
                    </option>
                  </select>
                </div>
                <label className="advanced_search__label">
                  {t('overview_doctype')}
                </label>
                <div>
                  <label
                    className="advanced_search__text container"
                    htmlFor="pdf">
                    &nbsp;&nbsp;PDF
                    <input
                      type="checkbox"
                      id="pdf"
                      value={PDF_TYPE}
                      checked={pdfType === true}
                      onChange={(e) => onDocTypeChange(e, PDF_TYPE)}
                    />
                    <span className="checkmark"></span>
                  </label>
                </div>
                <div>
                  <label
                    className={`${
                      ENABLED_DOC_TYPES.includes(DOC_TYPE)
                        ? 'advanced_search__text'
                        : 'advanced_search__text-disabled'
                    } container`}
                    htmlFor="word">
                    &nbsp;&nbsp;Word Document
                    <input
                      type="checkbox"
                      id="word"
                      value={DOC_TYPE}
                      checked={docType === true}
                      onChange={(e) => onDocTypeChange(e, DOC_TYPE)}
                      disabled={!ENABLED_DOC_TYPES.includes(DOC_TYPE)}
                    />
                    <span className="checkmark"></span>
                  </label>
                </div>
                <div>
                  <label
                    className={`${
                      ENABLED_DOC_TYPES.includes(EXCEL_TYPE)
                        ? 'advanced_search__text'
                        : 'advanced_search__text-disabled'
                    } container`}
                    htmlFor="excel">
                    &nbsp;&nbsp;Excel Sheet
                    <input
                      type="checkbox"
                      id="excel"
                      name="excelSearch"
                      value={EXCEL_TYPE}
                      checked={excelType === true}
                      onChange={(e) => onDocTypeChange(e, EXCEL_TYPE)}
                      disabled={!ENABLED_DOC_TYPES.includes(EXCEL_TYPE)}
                    />
                    <span className="checkmark"></span>
                  </label>
                </div>

                {/* <div>
                  <label className="advanced_search__label">
                    {t('overview_document_language')}
                  </label>
                  <select
                    id="language"
                    placeholder="Select Language(s)"
                    className="advanced_search__select advanced_search__select-disabled"
                    disabled>
                    <option value="latin">{t('overview_english')}</option>
                  </select>
                </div> */}
                <div>
                  <label className="advanced_search__label">
                    {t('overview_submittedby')}
                  </label>
                  <select
                    id="submissions"
                    className="advanced_search__select advanced_search__select-disabled"
                    disabled>
                    <option value="submission">{t('overview_all')}</option>
                  </select>
                </div>
                <div>
                  <label className="advanced_search__label">
                    {t('overview_date_range')}
                  </label>
                  {t('overview_between')}
                  <br />
                  <input
                    ref={startDateRef}
                    type="date"
                    onChange={(e) => onDateRangeChange(e, 'startDate')}
                    onBlur={(e) => onFocusOut(e, 'startDate')}
                    min={'1900-01-01'}
                    max={'2200-01-01'}
                  />
                  <br />
                  {t('overview_and')}
                  <br />
                  <input
                    ref={endDateRef}
                    type="date"
                    onChange={(e) => onDateRangeChange(e, 'endDate')}
                    onBlur={(e) => onFocusOut(e, 'endDate')}
                    min={'1900-01-01'}
                    max={'2200-01-01'}
                  />
                </div>
              </div>
              <br />
              <br /> <br />
            </React.Fragment>
          )}
        </div>
        {!isLoading && !isDetailedView && body.length !== 0 && (
          <div className="search-overview__search-table">
            <ListItem
              content={body}
              onTitleClick={(event, item) => showDetailedView(event, item)}
            />
          </div>
        )}
        {!isLoading && body.length === 0 && (
          <div className="search-overview__error-text">
            <label>{t('detail_no_results')}</label>
          </div>
        )}
        {!isLoading && isDetailedView && body.length !== 0 && (
          <div className="search-overview__error-text">
            <ErrorBoundary errorMessage={t('something_wrong')}>
              <DetailedView
                dataList={dataList}
                selectedDoc={selectedDoc}
                searchString={searchString}
                loggedUser={props.loggedUser}
              />
            </ErrorBoundary>
          </div>
        )}
      </div>
      {!isLoading && (
        <div className="search-overview__pagination">
          <Pagination
            handlePageChange={handlePageChange}
            paginationData={paginationData}
            activePage={activePage}
          />
        </div>
      )}
    </div>
  );
};

export default SearchOverview;
