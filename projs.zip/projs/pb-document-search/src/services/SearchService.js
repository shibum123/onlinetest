import axios from 'axios';
export default class SearchService {
  static getSearchData = async (
    access_token = '',
    accessToken = null,
    baseURL,
    data,
  ) => {
    return await axios.post(baseURL, data, {
      headers: {
        Authorization: `Bearer ${access_token ? access_token : accessToken}`,
        'Content-Type': 'application/json',
      },
    });
  };
}
