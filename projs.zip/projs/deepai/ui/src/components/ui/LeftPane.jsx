import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import Button from '@axaxl-web/button';
import Checkbox from '@axaxl-web/checkbox';
import Link from '@axaxl-web/link';
// import SearchBar from '@axaxl-web/search-bar';
import TextField from '@axaxl-web/text-field';
import Icon from '@axaxl-web/icon';

import './LeftPane.scss';

const LeftPane = (props) => {
    const { t } = useTranslation();

    const [dateRange, setDateRange] = useState({
        startDate: '1900-01-01 00:00:00',
        endDate: '2200-01-01 00:00:00',
    });
    const [text, setText] = useState('');

    const onDateRangeChange = (e, type) => {
        const dateVal = dateRange;
        if (e.target.value === '' || e.target.value === null) {
            if (type === 'startDate') {
                dateVal[type] = '1900-01-01 00:00:00';
            } else {
                dateVal[type] = '2200-01-01 00:00:00';
            }
        } else {
            if (type === 'startDate') {
                if (e.target.value > dateVal['endDate']) {
                    dateVal['endDate'] = e.target.value + ' 00:00:00';
                    dateVal['startDate'] = e.target.value + ' 00:00:00';
                    endDateRef.current.value = e.target.value;
                    startDateRef.current.value = e.target.value;
                }
            } else {
                if (dateVal['startDate'] > e.target.value) {
                    dateVal['endDate'] = e.target.value + ' 00:00:00';
                    dateVal['startDate'] = e.target.value + ' 00:00:00';
                    endDateRef.current.value = e.target.value;
                    startDateRef.current.value = e.target.value;
                }
            }
            dateVal[type] = e.target.value + ' 00:00:00';
        }
        setDateRange(dateVal);
    }

    const submitForm = () => {
        const data = {
            name: '',
            primary_party: text || '',

            startdate: dateRange.startDate
                ? dateRange.startDate
                : '1900-01-01 00:00:00',
            enddate: dateRange.endDate ? dateRange.endDate : '2200-01-01 00:00:00',
        };
        props.applyFilter(data);
    }


    const onTextChange = (event) => {
        setText(event.target.value);
    }

    const onReset = (event) => {
        event.preventDefault();

        setText('');

        setDateRange({
            startDate: '1900-01-01 00:00:00',
            endDate: '2200-01-01 00:00:00',
        });

        startDateRef.current.value = '1900-01-01 00:00:00';
        endDateRef.current.value = '2200-01-01 00:00:00';

        const data = {
            name: '',
            primary_party: '',

            startdate: '1900-01-01 00:00:00',
            enddate: '2200-01-01 00:00:00',
        };
        props.applyFilter(data);
    }

    const onChangeClearance = () => {

    }

    const onKeyPress = (e) => {
        if (e.keyCode === 13) {
            submitForm();
        }
    }

    const [cleared] = useState(false);
    const [notCleared] = useState(false);

    const startDateRef = React.useRef();
    const endDateRef = React.useRef();

    const textRef = React.useRef();

    return <div className="left-pane">
        <div className="left-pane__items">
            <div className="left-pane__title_container">
                <Icon fontSize="small" color="primary" name="close" className="left-pane__close" onClick={props.handleOnClose} />
            </div>
            <div className="left-pane__subheading">
                {t('leftpane.refine_search')}
            </div>
            <div className="left-pane__inline-container">
                <Button
                    className="left-pane__apply-button"
                    onClick={submitForm}
                    color="secondary">
                    {t('buttons.apply_filters')}
                </Button>
                <Link className="left-pane__link" onClick={onReset}>
                    {t('buttons.reset_button')}
                </Link>
            </div>
            <div className="left-pane__subheading">
                {t('leftpane.submission_date')}
            </div>
            {t('leftpane.date_between')}
            <br />
            <input
                ref={startDateRef}
                type="date"
                onChange={(e) => onDateRangeChange(e, 'startDate')}
                min={'1900-01-01'}
                max={'2200-01-01'}
            />
            <br />
            {t('leftpane.date_and')}
            <br />
            <input
                ref={endDateRef}
                type="date"
                onChange={(e) => onDateRangeChange(e, 'endDate')}
                min={'1900-01-01'}
                max={'2200-01-01'}
            />
            <div className="left-pane__subheading">
                {t('leftpane.primary_party')}
            </div>
            <TextField inputRef={textRef} value={text} className="left-pane__search-textfield" onChange={onTextChange} onKeyDown={onKeyPress} />
            {/* <SearchBar className="left-pane__search-text"  inputProps={{
                placeholder: 'Select Party',
                inputRef: inputRef
            }}
                buttonProps={{
                    color: 'primary',
                }} /> */}
            <div className="left-pane__subheading">
                {t('leftpane.clearance_status')}
            </div>
            <div
                className="left-pane__text-disabled"
                htmlFor="cleared">
                <Checkbox
                    id="cleared"
                    disabled
                    checked={cleared === true}
                    onChange={(e) => onChangeClearance(e, 'cleared')} />
                &nbsp;&nbsp;{t('leftpane.cleared')}
            </div>
            <br />
            <div
                className="left-pane__text-disabled"
                htmlFor="not_cleared">
                <Checkbox
                    id="not_cleared"
                    disabled
                    checked={notCleared === true}
                    onChange={(e) => onChangeClearance(e, 'notCleared')}
                />
                &nbsp;&nbsp;{t('leftpane.not_cleared')}
            </div>
            <br />
            <br />
        </div>
    </div>
}

export default LeftPane;
