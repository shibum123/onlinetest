#!/bin/bash

GREEN='\033[1;32m'
NC='\033[0m' # No Color

set -e

echo "\n${GREEN}Installing SDKMAN, if necessary...${NC}\n"
curl -s "https://get.sdkman.io" | bash
source "$HOME/.sdkman/bin/sdkman-init.sh"
echo "\n${GREEN}Installing Default JDK, if necessary...${NC}\n"
sdk install java || true
echo "\n${GREEN}Setting Environment Variables${NC}\n"
touch set_env_vars.sh
. set_env_vars.sh
echo "\n${GREEN}Starting Java Spring Boot Proxy${NC}\n"
(cd ../ && ./mvnw spring-boot:run)
