import React from 'react';
import './SelectedItem.scss';

export const SelectedItem = (props) => {
  const onClick = (event, type) => {
    event.preventDefault();
    props.doSearch(type === 'date' ? 'advanced' : 'basic');
  };
  return props.items.map((item, index) => {
    return (
      item &&
      item.label &&
      item.label !== null && (
        <div
          key={item.label + index}
          className="selected-item__selected-box"
          disabled={item.disabled}>
          <span className="selected-item__selected-text">{item.label}</span>
          &nbsp;&nbsp;
          {item.disabled && (
            <a
              href="#"
              className="selected-item__close-disabled"
              onClick={(event) => event.preventDefault()}
              disabled={item.disabled}
              aria-label="close">
              &times;
            </a>
          )}
          {!item.disabled && (
            <a
              href="#"
              className="selected-item__close"
              onClick={(event) => onClick(event, item.type)}
              aria-label="close">
              &times;
            </a>
          )}
        </div>
      )
    );
  });
};
