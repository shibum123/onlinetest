import React from 'react';
import HomePage from './HomePage';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';

const wrapper = shallow(<HomePage />);

describe('HomePage component', () => {
  it('should render correctly', () => {
    expect(wrapper.exists()).toBe(true);
  });

  // dynamic UUID / classnames not supported by onestart component
  xit('should match the snapshot', () => {

    let tree = renderer
      .create(<HomePage />)
      .toJSON();
    expect(tree).toMatchSnapshot();
  });
});
