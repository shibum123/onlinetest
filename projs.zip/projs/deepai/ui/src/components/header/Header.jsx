import React, { useEffect, useState } from 'react';
import logo from '../../assets/axa-logo.png';
import brandinglogo from '../../assets/deep-ai.svg';
import PortalService from '../../services/PortalService';
import Avatar from '@axaxl-web/avatar';

import './Header.scss';
import { useHistory } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

export const Header = (props) => {
    const history = useHistory();
    const { t } = useTranslation();
    const enableLogin = true;
    const portalService = new PortalService();
    const [loggedUser, setLoggedUser] = useState(null);

    useEffect(() => {
        portalService.getUser().then(resp => {
            setLoggedUser(resp)
        })
    }, []); // eslint-disable-line


    const onLogoClick = () => {
        history.push({
            pathname: '/'
        });
    };
    const handleKeyDown = (evt) => {
        if (evt.key === 'Enter') {
            onLogoClick();
        }
    };

    return (
        <div className="header">
            <div className="header-div">
                <div className="header-div__logo-container">
                    <img
                        src={logo}
                        tabIndex="1"
                        alt="axa logo"
                        onKeyDown={handleKeyDown}
                        className="header-div__logo-container-image"
                        onClick={() => onLogoClick()}
                    />
                    <img
                        src={brandinglogo}
                        alt="deep ai logo"
                        className="header-div__logo-container-branding-logo"
                        onKeyDown={handleKeyDown}
                        onClick={() => onLogoClick()}
                    />

                </div>
                <div className="header-div__title-container">
                    <div
                        className="header-div__title-text"
                        onClick={() => onLogoClick()}>
                        <center>{t('header.title')}</center>
                    </div>
                </div>
                <div className="header-div__avatar">
                    <div className="header-div__avatar-empty-div" />
                    {
                        enableLogin && loggedUser && loggedUser.profile_picture && <Avatar src={loggedUser.profile_picture} />
                    }
                </div>
            </div>
            <hr className="header__hr-header-bottom" />
        </div>
    );
};
