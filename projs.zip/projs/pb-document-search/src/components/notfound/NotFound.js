import React from 'react';
import { SearchHeader } from '../searchheader/SearchHeader';
import './NotFound.scss';
import logo from '../../assets/deep-ai.svg';
import { useTranslation } from 'react-i18next';

export const NotFound = () => {
  const { t } = useTranslation();
  return (
    <div className="notfound">
      <SearchHeader />
      <div className="notfound__help">
        <div className="notfound__help-circle">
          <div className="notfound__help-circle-text">?</div>
          <span className="notfound__help__tool-tip">{t('search_ui')}</span>
        </div>
        {t('help')}
      </div>
      <div className="notfound__logo">
        <img width="168px" height="48px" src={logo} alt="deep ai logo" />
        <div className="notfound__label">{t('notfound')}</div>
      </div>
    </div>
  );
};
