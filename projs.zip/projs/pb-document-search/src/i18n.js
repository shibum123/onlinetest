import i18n from 'i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

/* istanbul ignore next */
i18n.use(LanguageDetector).init({
  // we init with resources
  resources: {
    en: {
      translations: {
        help: 'HELP',
        search_ui: 'Search UI 1.0',
        search_button: 'SEARCH',
        close: 'Close',
        login: 'Login',
        logout: 'Logout',
        previous: 'Previous',
        exact_match: 'Exact word match',
        next: 'Next',
        notfound: 'The requested page not found',
        something_wrong: 'The requested data is not available...',
        overview_refine_search: 'Refine your search',
        overview_comp_selected: 'Company(s) Selected:',
        overview_tooltip:
          'Search based on literal matches of the query words or variants of them.',
        overview_apply_button: 'APPLY FILTERS',
        overview_reset_button: 'RESET ALL',
        overview_search_location: 'Search Location',
        overview_content: 'Content',
        overview_filename: 'File Name',
        overview_title: 'Title',
        overview_category: 'Category',
        overview_submissions: 'Submissions',
        overview_doctype: 'Document Type',
        overview_document_language: 'Document Language',
        overview_english: 'English',
        overview_submittedby: 'Submitted By',
        overview_date_range: 'Date Range',
        overview_between: 'Between ',
        overview_and: 'And ',
        overview_all: 'All',
        detail_submission: 'Submission',
        detail_download: 'DOWNLOAD',
        detail_no_preview: 'No Preview Available',
        detail_no_results: 'No Results to be shown',
        login_request: 'Please login to access the application',
        tabnavigation_word_search: 'WORD SEARCH',
        tabnavigation_semantic_search: 'SEMANTIC SEARCH',
        searchheader_searchtool: 'The Search Tool |',
        searchinput_searching_for: 'What are you searching for?',
      },
    },
  },
  fallbackLng: 'en',
  debug: true,

  // have a common namespace used around the full app
  ns: ['translations'],
  defaultNS: 'translations',

  keySeparator: false, // we use content as keys

  interpolation: {
    escapeValue: false, // not needed for react!!
    formatSeparator: ',',
  },

  react: {
    wait: true,
  },
});

export default i18n;
