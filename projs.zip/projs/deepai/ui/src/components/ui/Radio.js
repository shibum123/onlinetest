import React from 'react';
import wrapper from './wrapper';
import Radio from '@material-ui/core/Radio';

const AxaRadioButton = ({ gatedProps: { classes, children }, safeProps }) => {
  return (
    <Radio {...safeProps} type="radio" className={classes.root}>
      {children}
    </Radio>
  );
};

// Default props - default value for any props / variants the component has
// Gated props - props that we want passed into the axa component but not the mui component i.e color
// Blocked props - props that shouldn't be passed into axa or mui component i.e disableRipple
// Id - we can access in jest when writing unit tests
const config = {
  styles: {
    root: {
      color: '#00008f',
      '&.Mui-checked': {
        color: '#00008f',
      },
      '&:hover': {
        backgroundColor: '#00008f',
      },
      '&:active': {
        backgroundColor: `#00008f`,
      }
    },
  },
  blockedProps: [
    'icon',
    'indeterminate',
    'indeterminateIcon',
    'inputProps',
    'checkedIcon',
    'color',
    'size',
    'type',
  ],
};

export default wrapper(AxaRadioButton, config);
