module.exports = {
  parser: 'babel-eslint',
  env: {
    browser: true,
    es6: true,
  },
  extends: ['plugin:react/recommended'],
  globals: {
    Atomics: 'readonly',
    SharedArrayBuffer: 'readonly',
  },
  parserOptions: {
    ecmaFeatures: {
      jsx: true,
    },
    ecmaVersion: 2018,
    sourceType: 'module',
  },
  plugins: ['react'],
  rules: {
    quotes: ['off', 'double'],
    'comma-dangle': ['off'],
    'no-unused-vars': ['error', { vars: 'all', args: 'none' }],
    'arrow-body-style': ['off'],
    camelcase: ['off'],
    indent: ['off'],
    semi: ['off'],
    'arrow-parens': ['off'],
    'react/prop-types': ['off'],
    'import/no-cycle': ['off'],
    'react/destructuring-assignment': ['off'],
    'no-param-reassign': ['off'],
  },
};
