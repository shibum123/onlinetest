import React from 'react';
import { NotFound } from './NotFound';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';

jest.mock('react-router-dom', () => {
    const historyObj = {
        push: jest.fn()
    };

    return {
        ...jest.requireActual('react-router-dom'),
        useHistory: () => historyObj
    }
});

const wrapper = shallow(<NotFound />);

describe('NotFound component', () => {
    it('should render correctly', () => {
        expect(wrapper.exists()).toBe(true);
    });

    it('should match the snapshot', () => {
        expect(wrapper).toMatchSnapshot(true);

        let tree = renderer
            .create(<NotFound />)
            .toJSON();
        expect(tree).toMatchSnapshot();
    })
});