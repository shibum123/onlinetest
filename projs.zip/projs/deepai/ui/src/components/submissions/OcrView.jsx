import React, { useEffect, useState } from 'react';
import './NewSubmission.scss';
import './styles.css';
import { Ripple } from 'react-awesome-spinners';
import myPdf from './test.pdf'

import Typography from '@axaxl-web/typography';
import Button from '@axaxl-web/button';

import { useTranslation } from 'react-i18next';
import { DropzoneArea } from 'material-ui-dropzone';
import { useSelector } from 'react-redux';
import { Submissions } from './Submissions';

// import SinglePagePDFViewer from "./single-page";
import AllPagesPDFViewer from "./all-pages";

const OcrView = (props) => {
    const { t } = useTranslation();
    const { submission } = useSelector(state => state.submissions)
    const { files } = useSelector(state => state.submissions);

    const [isLoading, setIsLoading] = useState(false);

    const [file, setFile] = useState([]);
    const [convertedFileData, setConvertedFileData] = useState('');

    const submissions = new Submissions();

    const [isDetailedView, setIsDetailedView] = useState('text-view');

    useEffect(() => {
        const elem = document.getElementsByClassName('MuiDropzoneArea-textContainer');

        const fileIcon = document.getElementById('newsubmission__button-submit-hidden');
        const clone = fileIcon.cloneNode(true);
        clone.id = `button-submit-visible`;

        const pTag = document.createElement('center');
        pTag.appendChild(clone)
        clone.classList.add("newsubmission__button-submit-visible");
        if (!document.getElementById('button-submit-visible')) {
            elem[0].appendChild(pTag);
        }
    })

    const toggleView = (viewName) => {
        if (viewName === 'pdf-view') {
            setIsDetailedView('pdf-view');
        } else if (viewName === 'split-view') {
            setIsDetailedView('split-view');
        } else {
            setIsDetailedView('text-view');
        }
    };


    const handleChange = async (loadedFiles) => {
        setFile(loadedFiles);
    }

    const onConvertToText = () => {
        setIsLoading(true);
        setConvertedFileData('');
        submissions.onConvertToText(file, document.getElementById('searchablePdf').checked === true ? 'y' : 'n')
            .then(data => {
                setConvertedFileData(data);
                setIsLoading(false);
            })
            .catch(error => {
                setIsLoading(false);
            })
    }

    const download = (filename, text) => {
        var element = document.createElement('a');
        element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
        element.setAttribute('download', filename);

        element.style.display = 'none';
        document.body.appendChild(element);

        element.click();

        document.body.removeChild(element);
    }

    return <div className="newsubmission">
        {isLoading && (
            <div className="loader">
                <Ripple />
            </div>
        )}
        <Button id="newsubmission__button-submit-hidden" className="newsubmission__button-submit-visible">{t('buttons.upload_file')}</Button>
        <div className="newsubmission__title_container">
            <Typography variant="moduleTitle" className="ocrview__title" >{t('submission.upload_doc_title')}</Typography>
        </div>
        <div className="ocrview__inline">
            <div className="newsubmission__dropzonecontainer_view">
                {files.length !== 0 && <DropzoneArea id="submission-docupload"
                    onChange={handleChange}
                    showFileNamesInPreview={true}
                    showPreviews={true}
                    showPreviewsInDropzone={false}
                    zeroMinWidth={true}
                    previewGridProps={{ item: { spacing: 10, direction: 'row' } }}
                    dropzoneText={t('submission.drop_files')}
                    filesLimit={1}
                    initialFiles={files}
                    fullWidth={false}
                />}
                {files.length === 0 && <DropzoneArea id="submission-docupload"
                    onChange={handleChange}
                    showFileNames={true}
                    dropzoneText={t('submission.drop_files')}
                    filesLimit={1}
                />}
            </div>
            <div className="newsubmission__button-container">
                <label
                    htmlFor="searchablePdf">
                    {t('ocr_view.searchable_pdf')}
                    <input type="checkbox" id="searchablePdf" />
                    <span className="checkmark"></span>&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
                {file.length > 0 && <Button className="ocrview__button" onClick={() => onConvertToText(submission.id)}>Convert To Text</Button>}
                {file.length <= 0 && <Button className="ocrview__button" onClick={() => onConvertToText(submission.id)} disabled>Convert To Text</Button>}&nbsp;&nbsp;&nbsp;
                {convertedFileData && convertedFileData.data && convertedFileData.data.content && <Button className="ocrview__button" onClick={() => download(`${convertedFileData.data.filename}.txt`, convertedFileData.data.content.toString())}>Download</Button>}
            </div>
            <br />
            <div className="ocrview__view-toggle-container">
                { isDetailedView === 'pdf-view' && <Button className="ocrview__button-selected" onClick={() => toggleView('pdf-view')}>PDF View&nbsp;&nbsp; <i className="fa fa-file-pdf-o"></i></Button>}
                { isDetailedView !== 'pdf-view' && <Button className="ocrview__button-not-selected" onClick={() => toggleView('pdf-view')}>PDF View&nbsp;&nbsp; <i className="fa fa-file-pdf-o"></i></Button>} &nbsp;
                { isDetailedView === 'text-view' && <Button className="ocrview__button-selected" onClick={() => toggleView('text-view')}>Text View</Button> }
                { isDetailedView !== 'text-view' && <Button className="ocrview__button-not-selected" onClick={() => toggleView('text-view')}>Text View</Button> } &nbsp;
                { isDetailedView === 'split-view' && <Button className="ocrview__button-selected" onClick={() => toggleView('split-view')}>Split View</Button> }
                { isDetailedView !== 'split-view' && <Button className="ocrview__button-not-selected" onClick={() => toggleView('split-view')}>Split View</Button> }
            </div>
            <center>
                {isDetailedView === 'split-view' && <div className="ocrview__inline-container">
                    {/*  {convertedFileData && convertedFileData.data && <center><SinglePagePDFViewer pdf={`data:application/pdf;base64, ${convertedFileData.data.searchablePDF}`} /></center>} */}
                    {convertedFileData && convertedFileData.data && <div className="ocrview__content-splitview">{convertedFileData.data.content.toString()}</div>}
                    {convertedFileData && convertedFileData.data && <center><div className="ocrview__pdf-splitview"><AllPagesPDFViewer pdf={`data:application/pdf;base64, ${convertedFileData.data.searchablePDF}`} /></div></center>}
                </div>}
                {isDetailedView === 'text-view' && <div className="ocrview__inline-container">
                    {convertedFileData && convertedFileData.data && <div className="ocrview__contentview">{convertedFileData.data.content.toString()}</div>}
                </div>}
                {isDetailedView === 'pdf-view' && <div className="ocrview__inline-container">
                    {convertedFileData && convertedFileData.data && <div className="ocrview__pdfview"><center><AllPagesPDFViewer pdf={`data:application/pdf;base64, ${convertedFileData.data.searchablePDF}`} /></center></div>}
                </div>}
            </center>
            <center><AllPagesPDFViewer pdf={myPdf} /></center>
        </div>
    </div>
}
export default OcrView;