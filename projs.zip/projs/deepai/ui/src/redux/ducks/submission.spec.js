import React from 'react';
import { filterResults } from '../../redux/ducks/submissions';
import { data } from './submissiondata';

describe('Submission reducer function', () => {
    it('should return empty array when empty data and empty search string', () => {
        expect(filterResults([], { name: '' })).toEqual([]);
    });

    it('should return empty array when empty data', () => {
        expect(filterResults([], { name: 'test-sh' })).toEqual([]);
    });

    it('should return empty array when empty string', () => {
        expect(filterResults([], { name: '' })).toEqual([]);
    });

    it('should return empty array when null string', () => {
        expect(filterResults([], { name: null })).toEqual([]);
    });

    it('should return filtered array for non null name', () => {
        expect(filterResults(data, { name: 'test-sh' })).toEqual(
            [{
                "id": "601ecf60e1feed0dc18973b1",
                "name": "test-sh",
                "owner": "659dc281-c63d-4cad-854e-45de9aca0bb8",
                "submittedTime": 1612631904.014,
                "processedTime": null,
                "processingStatus": "pending",
                "processingProgress": 0,
                "files": []
            }]
        );
    });

    it('should return filtered array when date not set', () => {
        expect(filterResults(data, { name: 'test-sh', startdate: '1900-01-01 00:00:00', enddate: '2200-01-01 00:00:00' })).toEqual(
            [{
                "id": "601ecf60e1feed0dc18973b1",
                "name": "test-sh",
                "owner": "659dc281-c63d-4cad-854e-45de9aca0bb8",
                "submittedTime": 1612631904.014,
                "processedTime": null,
                "processingStatus": "pending",
                "processingProgress": 0,
                "files": []
            }]
        );
    });

    it('should return empty array when nothing matches', () => {
        expect(filterResults(data, { name: 'test-sh-test', startdate: '1900-01-01 00:00:00', enddate: '2200-01-01 00:00:00' })).toEqual(
            []
        );
    });

    it('should return full array for the correct date range', () => {
        expect(filterResults(data, { name: '', startdate: '1900-01-01 00:00:00', enddate: '2200-01-01 00:00:00' })).toEqual(
            data
        );
    });

    it('should return filtered array for the correct date range', () => {
        expect(filterResults(data, { name: '', startdate: '2021-02-05 00:00:00', enddate: '2021-02-08 00:00:00' })).toEqual(
            [{
                "id": "601ecf60e1feed0dc18973b1",
                "name": "test-sh",
                "owner": "659dc281-c63d-4cad-854e-45de9aca0bb8",
                "submittedTime": 1612631904.014,
                "processedTime": null,
                "processingStatus": "pending",
                "processingProgress": 0,
                "files": []
            }]
        );
    });
});
