/* eslint-disable react/forbid-foreign-prop-types */
import React from 'react';
import {
  withStyles,
  createMuiTheme,
  ThemeProvider,
  createGenerateClassName,
  StylesProvider,
} from '@material-ui/core/styles';

// Go through the props and reorganize them into gated, blocked, and safe props
const filterProps = (props, gatedPropsSet, blockedPropsSet) => {
  const gatedProps = {};
  const blockedProps = {};
  const safeProps = {};
  Object.keys(props).forEach(propName => {
    if (blockedPropsSet.has(propName)) {
      blockedProps[propName] = props[propName];
    } else if (gatedPropsSet.has(propName)) {
      gatedProps[propName] = props[propName];
    } else {
      safeProps[propName] = props[propName];
    }
  });
  return [gatedProps, blockedProps, safeProps];
};

const commonGatedProps = ['classes', 'className', 'children', 'data-testid'];
const commonBlockedProps = [];

const wrapper = (
  WrappedComponent,
  {
    styles = {},
    propTypes = {},
    defaultProps = {},
    gatedProps = [],
    blockedProps = [],
  } = {}
) => {
  const theme = createMuiTheme();
  const gatedPropsSet = new Set([...gatedProps, ...commonGatedProps]);
  const blockedPropsSet = new Set([...blockedProps, ...commonBlockedProps]);

  function generateUUID() {
    // Public Domain/MIT
    var d = new Date().getTime(); //Timestamp
    var d2 = (performance && performance.now && performance.now() * 1000) || 0; //Time in microseconds since page-load or 0 if unsupported
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      var r = Math.random() * 16; //random number between 0 and 16
      if (d > 0) {
        //Use timestamp until depleted
        r = (d + r) % 16 | 0;
        d = Math.floor(d / 16);
      } else {
        //Use microseconds since page-load if supported
        r = (d2 + r) % 16 | 0;
        d2 = Math.floor(d2 / 16);
      }
      return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
    });
  }

  const generateClassName = createGenerateClassName({
    productionPrefix: 'axa-',
    seed: generateUUID(),
    disableGlobal: true,
  });

  const Wrapper = props => {
    // pass gatedProps and safeProps into the axa component - blockedProps to be used at a later date
    /* eslint-disable-next-line no-unused-vars */
    const [gatedProps, blockedProps, safeProps] = filterProps(
      props,
      gatedPropsSet,
      blockedPropsSet
    );

    const datatestid = gatedProps['data-testid'] || WrappedComponent.name;
    return (
      <ThemeProvider theme={theme}>
        <WrappedComponent
          safeProps={{ ...safeProps, 'data-testid': datatestid }}
          gatedProps={gatedProps}
        />
      </ThemeProvider>
    );
  };

  const StyledComponent = withStyles(styles)(Wrapper);

  Object.assign(StyledComponent, {
    propTypes,
    defaultProps,
    displayName: WrappedComponent.name,
  });

  return props => (
    <>
      {process.env.NODE_ENV !== 'production' ? (
        <StyledComponent {...props} />
      ) : (
        <StylesProvider injectFirst generateClassName={generateClassName}>
          <StyledComponent {...props} />
        </StylesProvider>
      )}
    </>
  );
};

export default wrapper;
