import PortalService from '../../services/PortalService'

export class Submissions {

    constructor() {
        this.portalService = new PortalService();
    }

    getAllSubmissions = async () => {
        return await this.portalService.getSubmissions();
    }

    createSubmission = async (req) => {
        return await this.portalService.createSubmission(req);
    }

    editSubmission = async (req, selectedSubmissionId) => {
        return await this.portalService.editSubmission(req, selectedSubmissionId);
    }

    onConvertToText = async(file, isSearchablePDF) => {
        return await this.portalService.onConvertToText(file, isSearchablePDF)
    }

    downloadSubmissionFile = async (req) => {
        return await this.portalService.downloadSubmissionFile(req);
    }

    deleteSubmission = async (submissionId) => {
        return await this.portalService.deleteSubmission(submissionId);
    }

    getProcessingStatus = async (ids) => {
        return await this.portalService.getProcessingStatus(ids);
    }
} 