import React from 'react';
import './TabNavigation.scss';
import { useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

export const TabNavigation = (props) => {
  const location = useLocation();
  const { t } = useTranslation();
  const showContent = (evt, content) => {
    evt.preventDefault();
    props.handleTabChange(content);
  };

  let path_name2 =
    location.pathname === '/semantic' ||
    location.pathname === '/semantic-advanced'
      ? 'active'
      : '';
  let path_name1 =
    location.pathname !== '/semantic' &&
    location.pathname !== '/semantic-advanced'
      ? 'active'
      : '';

  return (
    <div className="tabNavigation">
      {' '}
      <a
        id="keyword"
        className={`tabNavigation ${path_name1}`}
        href="#"
        tabIndex="3"
        onClick={(event) => showContent(event, 'keyword')}>
        {t('tabnavigation_word_search')}
      </a>{' '}
      <a
        id="semantic"
        className={`tabNavigation ${path_name2}`}
        href="#"
        tabIndex="4"
        onClick={(event) => showContent(event, 'semantic')}>
        {t('tabnavigation_semantic_search')}
      </a>
    </div>
  );
};
