export const backendBaseUrl = process.env.REACT_APP_BACKEND_BASE_URL
  ? process.env.REACT_APP_BACKEND_BASE_URL
  : '/api/services';
export const searchUrl = process.env.REACT_APP_SEARCH_URL;

export const previousUrlKeyName = 'AXAXL_FE_PREVIOUS_URL';

export const PENDING = 'pending';
export const CREATING = 'creating';
export const COMPLETED = 'complete';
export const CLEARED = 'cleared';
export const NOT_CLEARED = 'not cleared';
export const DELAY = 15000;
export const MAX_DELAY = 30 * 60 * 1000;

export const VIEW_REPORT = 'VIEW_REPORT';
export const EDIT_SUBMISSION = 'EDIT_SUBMISSION';
export const SET_PRIMARY_PARTY = 'SET_PRIMARY_PARTY';
export const NEW_SUBMISSION = 'NEW_SUBMISSION';
