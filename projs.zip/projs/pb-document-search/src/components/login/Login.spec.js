import React from 'react';
import { Login } from './Login';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';

jest.mock('react-router-dom', () => {
    const historyObj = {
        push: jest.fn()
    };

    return {
        ...jest.requireActual('react-router-dom'),
        useHistory: () => historyObj,
        useLocation: () => ({
            pathname: "/"
        })
    }
});

const wrapper = shallow(<Login />);

describe('login component', () => {
    it('should render correctly', () => {
        expect(wrapper.exists()).toBe(true);
    });

    it('should match the snapshot', () => {
        expect(wrapper).toMatchSnapshot(true);

        let tree = renderer
            .create(<Login />)
            .toJSON();
        expect(tree).toMatchSnapshot();
    })
});