import {
  REACT_APP_BASE_URL,
  REACT_APP_DOC_SOURCE,
  REACT_APP_REDIRECT_URI,
} from './environment';
import { PDF_TYPE, DOC_TYPE } from './utils/AppConstants';
export const BASE_URL = REACT_APP_BASE_URL;
export const DOC_SOURCE = REACT_APP_DOC_SOURCE;
export const PAGE_SIZE = 10;
export const CONTENT_LENGTH = 0;
export const PREVIEW_LENGTH = 400;
export const INDEX_NAME = process.env.INDEX_NAME;
export const CLIENT_ID = process.env.REACT_APP_CLIENT_ID;
export const AUTHORITY_URL = process.env.REACT_APP_AUTHORITY_URL;
export const REDIRECT_URI = REACT_APP_REDIRECT_URI;
export const ENABLED_DOC_TYPES = [PDF_TYPE, DOC_TYPE]; // PDF - default value
export const ENABLE_FACETED_SEARCH = true;
export const PROXY_URL = process.env.REACT_APP_PROXY_URL;
export const APIM_KEY = process.env.REACT_APP_APIM_KEY;
