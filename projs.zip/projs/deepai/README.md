# Frontend Proxy Application 

This is a boilerplate frontend proxy application encompassing a variety of usage scenarios:

1. Running a single executable .jar (i.e. "hosted" mode)
2. Running a node proxy to serve up the React app (i.e. "development" mode)
...and possibly more? Stay up to date by upgrading to the latest onestart-prototype-frontend-proxy

See the [onestart-prototype-frontend-proxy README](https://dev.azure.com.us.cas.ms/xlcatlin/oneStart/_git/onestart-java-framework?path=%2Fonestart-prototypes%2Fonestart-prototype-frontend-proxy%2FREADME.md&_a=preview) for the latest docs and howtos.
