import React, { useEffect, useState } from 'react';

import Typography from '@axaxl-web/typography';
import Button from '@axaxl-web/button';
import Table from '@axaxl-web/table';
import TableBody from '@axaxl-web/table-body';
import TableHead from '@axaxl-web/table-head';
import TableRow from '@axaxl-web/table-row';
import TableCell from '@axaxl-web/table-cell';
import PortalService from '../../services/PortalService';

import { useSelector, useDispatch } from 'react-redux';
import { setParties } from './../../redux/ducks/submissions';
import { makeStyles } from '@material-ui/core/styles';
import AxaRadio from './../ui/AXARadio';
import { setSnackbar } from '../../redux/ducks/general';
import { useTranslation } from 'react-i18next';

import './PrimaryPartySelection.scss';

const PrimaryPartySelection = (props) => {
    const { t } = useTranslation();

    const { parties } = useSelector(state => state.submissions);
    const { partySubmissionId } = useSelector(state => state.submissions)

    const [selectedCompanyId, setSelectedCompanyId] = useState(null);

    const dispatch = useDispatch();
    const portalService = new PortalService();

    const useStyles = makeStyles({
        root: {
            color: 'blue !important'
        },
    });

    const classes = useStyles();

    useEffect(() => {
        portalService.getPrimaryParties({ partySubmissionId: partySubmissionId }).then(resp =>
            dispatch(setParties(resp && resp.companies ? resp.companies : [])))
    }, []); // eslint-disable-line

    const onSubmit = () => {
        portalService.setPrimaryParty({ partySubmissionId: partySubmissionId, companyId: selectedCompanyId })
            .then((resp) => {
                if (resp && (resp.status === 200 || resp.statusText === 'OK')) {
                    dispatch(setSnackbar(true, 'success', t('success.primary_party')));
                    props.handlePartyClose();
                } else {
                    dispatch(setSnackbar(true, 'error', t('error.primary_party')));
                }
            })
    }

    const handleChange = (value) => {
        setSelectedCompanyId(value);
    }

    return <div className="primaryPartySelection">
        <Typography variant="moduleTitle" className="primaryPartySelection__title">{t('primary_party.select')}</Typography>
        <Typography variant="textStandard" className="primaryPartySelection__sub-text">{t('primary_party.title')}</Typography>
        <div className="primaryPartySelection__parties">
            <Table>
                <TableHead>
                    <TableRow>
                        <TableCell>{t('primary_party.table_col_identified')}</TableCell>
                        <TableCell>{t('primary_party.table_col_duns_number')}</TableCell>
                        <TableCell>{t('primary_party.table_col_primary_address')}</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {
                        parties ? parties.map(party => {
                            return <TableRow>
                                <TableCell>
                                    <AxaRadio checked={selectedCompanyId === party.id}
                                        onChange={() => handleChange(party.id)}
                                        name="primaryParty"
                                        value={party.companyName}
                                        className={classes.root} />
                                    &nbsp;
                                    {party.companyName}</TableCell>
                                <TableCell>{party.dunsNumber}</TableCell>
                                <TableCell>{party.address.streetAddress}</TableCell>
                            </TableRow>
                        }) : []
                    }
                </TableBody>
            </Table>
        </div>
        <div className="primaryPartySelection__button-container">
            <Button className="primaryPartySelection__button" onClick={props.handlePartyClose}>{t('buttons.cancel')}</Button>&nbsp;&nbsp;&nbsp;
            {selectedCompanyId !== null && <Button className="primaryPartySelection__button" onClick={onSubmit} >{t('buttons.done')}</Button>}
            {selectedCompanyId === null && <Button className="primaryPartySelection__button" onClick={onSubmit} disabled>{t('buttons.done')}</Button>}
        </div>
    </div>
}

export default PrimaryPartySelection;