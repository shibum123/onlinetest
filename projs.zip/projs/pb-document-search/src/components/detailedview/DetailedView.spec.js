import React from 'react';
import { DetailedView } from './DetailedView';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';
import { render } from '@testing-library/react';

jest.mock('react-router-dom', () => {
  const historyObj = {
    push: jest.fn(),
  };

  return {
    ...jest.requireActual('react-router-dom'),
    useHistory: () => historyObj,
  };
});

jest.mock('react-i18next', () => ({
  useTranslation: () => ({ t: (key) => key }),
}));

const dataItem = [
  {
    "Content-Type": "application/pdf",
    "_id": "c9b5bf74b76c909002ebd4289af8d07f813f9391e1aaef3dc0d7ed1f3890d993",
    "content": "Signature of Representative: Producer: Date: oo ()) by Date:    Chubb. Insured.’ IT 1913 | Version date: 01-2017 © 2017 Chubb 5",
    "create_date": "2020-06-18 11:15:39",
    "document_source": "partybot",
    "email": "vaibhav.khanna1@axaxl.com",
    "filename": "2019 Foreign Package application.pdf",
    "filesize": 2058945,
    "filetype": "application/pdf",
    "full_file_path": "vaibhav.khanna1@axaxl.com/2019 Foreign Package application.pdf",
    "language": "",
    "pages": 5,
    "parent_folder": "vaibhav.khanna1@axaxl.com",
    "parsed_date": "2020-06-18 11:15:47.227555",
    "relative_path": "vaibhav.khanna1@axaxl.com/2019 Foreign Package application.pdf",
    "title": "",
    "url": null
  }
]

const dataItem1 = [
  {
    "Content-Type": "application/pdf",
    "_id": "c9b5174b76c909002ebd4289af8d07f813f9391e1aaef3dc0d7ed1f3890d993",
    "content": "Signature of Representative: Producer: Date: oo ()) by Date:    Chubb. Insured.’ IT 1913 | Version date: 01-2017 © 2017 Chubb 5",
    "create_date": "2020-06-18 11:15:39",
    "document_source": "partybot",
    "email": "vaibhav.khanna1@axaxl.com",
    "filename": "2020 Foreign Package application.pdf",
    "filesize": 2058945,
    "filetype": "application/pdf",
    "full_file_path": "vaibhav.khanna1@axaxl.com/2019 Foreign Package application.pdf",
    "language": "",
    "pages": 5,
    "parent_folder": "vaibhav.khanna1@axaxl.com",
    "parsed_date": "2020-06-18 11:15:47.227555",
    "relative_path": "vaibhav.khanna1@axaxl.com/2019 Foreign Package application.pdf",
    "title": "",
    "url": null
  },
  {
    "Content-Type": "application/pdf",
    "_id": "c9b5174b76c909002ebd4289af8d07f813f9391e1aaef3dc0d7ed1f3890d993",
    "content": "Signature of Representative: Producer: Date: oo ()) by Date:    Chubb. Insured.’ IT 1913 | Version date: 01-2017 © 2017 Chubb 5",
    "create_date": "2021-06-18 11:15:39",
    "document_source": "partybot",
    "email": "shibu.manoharan@contractor.axaxl.com",
    "filename": "2020 Foreign Package application.pdf",
    "filesize": 2058945,
    "filetype": "application/pdf",
    "full_file_path": "shibu.manoharan@contractor.axaxl.com/2019 Foreign Package application.pdf",
    "language": "",
    "pages": 5,
    "parent_folder": "shibu.manoharan@contractor.axaxl.com",
    "parsed_date": "2020-06-18 11:15:47.227555",
    "relative_path": "shibu.manoharan@contractor.axaxl.com/2019 Foreign Package application.pdf",
    "title": "",
    "url": null
  },
  {
    "Content-Type": "application/pdf",
    "_id": "c9b5174b76c909002ebd4289af8d07f813f9391e1aaef3dc0d7ed1f3890d993",
    "content": "Signature3 of Representative: Producer: Date: oo ()) by Date:    Chubb. Insured.’ IT 1913 | Version date: 01-2017 © 2017 Chubb 5",
    "create_date": "2020-06-18 11:15:39",
    "document_source": "partybot",
    "email": "vaibhav.khanna1@axaxl.com",
    "filename": "2020 Foreign Package application.pdf",
    "filesize": 2058945,
    "filetype": "application/pdf",
    "full_file_path": "vaibhav.khanna1@axaxl.com/2019 Foreign Package application.pdf",
    "language": "",
    "pages": 5,
    "parent_folder": "vaibhav.khanna1@axaxl.com",
    "parsed_date": "2020-06-18 11:15:47.227555",
    "relative_path": "vaibhav.khanna1@axaxl.com/2019 Foreign Package application.pdf",
    "title": "",
    "url": null
  }
]

let wrapper = shallow(
  <DetailedView dataList={[]} selectedDoc={null} searchString="policy" />,
);

describe('DetailedView component', () => {
  it('should render correctly', () => {
    expect(wrapper.exists()).toBe(true);
  });

  it('should render list items', () => {
    const { getByTestId } = render(
      <DetailedView dataList={dataItem} selectedDoc={dataItem[0]} searchString="policy" />
    );
    expect(getByTestId('list-item').children.length).toBe(1);
  });

  it('should render multiple list items', () => {
    const { getByTestId } = render(
      <DetailedView dataList={dataItem1} selectedDoc={dataItem1[1]} searchString="policy" />
    );
    expect(getByTestId('list-item').children.length).toBe(3);
  })

  it('should match the snapshot', () => {
    expect(wrapper).toMatchSnapshot(true);

    let tree = renderer
      .create(
        <DetailedView dataList={dataItem} selectedDoc={dataItem[0]} searchString="policy" />,
      )
      .toJSON();
    expect(tree).toMatchSnapshot();
  });
});
