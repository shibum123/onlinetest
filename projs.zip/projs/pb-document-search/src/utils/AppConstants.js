export const PDF_TYPE = ".pdf";
export const EXCEL_TYPE = ".xls";
export const DOC_TYPE = ".doc";
