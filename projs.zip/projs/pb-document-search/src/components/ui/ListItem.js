import React from 'react';
import { PREVIEW_LENGTH } from '../../config';

export const ListItem = (props) => {
  return props.content.map((item, index) => {
    return (
      <React.Fragment key={`listitem${index}`}>
        <div
          className="search-overview__title-label"
          onClick={(event) => props.onTitleClick(event, item.dataListItem)}>
          {item.filename}
        </div>
        {item.create_date && (
          <div className="search-overview__subtitle-label">
            {`Submitted: ${item.create_date.split('-')[0]}`}
          </div>
        )}
        <div className="search-overview__content-label">
          {PREVIEW_LENGTH === 0
            ? item.content.props.children
            : item.content.props.children.substring(0, PREVIEW_LENGTH)}
        </div>
        <br />
      </React.Fragment>
    );
  });
};
