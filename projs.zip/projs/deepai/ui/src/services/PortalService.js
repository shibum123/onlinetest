import RestAPIClient from '../api/restAPI';
import ErrorHandler from '../ErrorHandler';

export class PortalService {

    constructor() {
        this.errorHandler = new ErrorHandler();
    }

    async getUser() {
        let user;
        await (RestAPIClient.getUser()
            .then(resp => {
                user = resp.data;
            })
        )
        return user;
    }

    async getProcessingStatus(ids) {
        let progress;
        await RestAPIClient.getProcessingStatus(ids)
            .then((res) => {
                progress = res;
            })
            .catch(err => {
                this.errorHandler.handleErrors(err, 'error while getting submission status');
            })
        return progress;
    }

    async getSubmissions() {
        let submissions;
        await RestAPIClient.getSubmissions()
            .then((res) => {
                submissions = res.data;
            })
            .catch(err => {
                this.errorHandler.handleErrors(err, 'error while getting submissions')
            })
        return submissions;
    }

    async getPrimaryParties(req) {
        let parties
        await RestAPIClient.getPrimaryParties(req)
            .then((resp) => {
                parties = resp.data
            })
            .catch(err => {
                this.errorHandler.handleErrors(err, 'error while getting primary parties')
            })
        return parties;
    }

    async setPrimaryParty(req) {
        let response;
        await RestAPIClient.setPrimaryParty(req)
            .then((res) => {
                response = res;
            })
            .catch(err => {
                this.errorHandler.handleErrors(err, 'error while setting the primary party')
            })
        return response;
    }


    async createSubmission(req) {
        let created = false;
        await RestAPIClient.createSubmission(req)
            .then((res) => {
                created = true;
            })
            .catch(err => {
                this.errorHandler.handleErrors(err, 'error while creating submission')
            })
        return created;
    }

    async onConvertToText(file, isSearchablePDF) {
        let data = null;
        await RestAPIClient.onConvertToText(file, isSearchablePDF)
            .then((res) => {
                data = res;
            })
            .catch(err => {
                this.errorHandler.handleErrors(err, 'error while converting x2text')
            })
        return data;
    }

    async editSubmission(req, selectedSubmissionId) {
        let edited = false;
        await RestAPIClient.editSubmission(req, selectedSubmissionId)
            .then((res) => {
                edited = true;
            })
            .catch(err => {
                this.errorHandler.handleErrors(err, 'error while editing submission')
            })
        return edited;
    }

    async getSubmissionsByStatus(status) {
        let submissions;
        await RestAPIClient.getSubmissionStatus(status)
            .then((res) => {
                submissions = res.data;
            })
            .catch(err => {
                this.errorHandler.handleErrors(err, 'submissions by status')
            })
        return submissions;
    }

    async downloadSubmissionFile(fileId) {
        let files = [];
        await RestAPIClient.downloadSubmissionFile(fileId)
            .then(res => {
                if (res && res.length > 0) {
                    res.forEach(item => {
                        files.push(item.data);
                    })
                }
                return files;
            })
            .catch(err => {
                this.errorHandler.handleErrors(err, 'file loading failed')
            });
        return files;
    }

    async deleteSubmission(submissionId) {
        let removed = false;
        await RestAPIClient.deleteSubmission(submissionId)
            .then((res) => {
                removed = true;
            })
            .catch(err => {
                this.errorHandler.handleErrors(err, 'error while deleting the submission')
            })
        return removed;
    }
}

export default PortalService;