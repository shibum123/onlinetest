import React from 'react';
import { SearchHeader } from './SearchHeader';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';

jest.mock('react-router-dom', () => {
    const historyObj = {
        push: jest.fn()
    };

    return {
        ...jest.requireActual('react-router-dom'),
        useHistory: () => historyObj,
        useLocation: () => ({
            pathname: "/search"
        })
    }
});

const wrapper = shallow(<SearchHeader enableLogin={true} />);

describe('SearchHeader component', () => {
    it('should render correctly', () => {
        expect(wrapper.exists()).toBe(true);
    });

    it('should match the snapshot', () => {
        let tree = renderer
            .create(<SearchHeader enableLogin={true} />)
            .toJSON();
        expect(tree).toMatchSnapshot();

        tree = renderer
        .create(<SearchHeader enableLogin={false} />)
        .toJSON();
        expect(tree).toMatchSnapshot();
    });
});