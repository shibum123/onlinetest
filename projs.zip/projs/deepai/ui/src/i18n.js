import i18n from 'i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

/* istanbul ignore next */
i18n.use(LanguageDetector).init({
  // we init with resources
  resources: {
    en: {
      translations: {
        'buttons.save_draft': 'SAVE DRAFT',
        'buttons.delete': 'DELETE',
        'buttons.cancel': 'Cancel',
        'buttons.close': 'Close',
        'buttons.submit': 'Submit',
        'buttons.done': 'DONE',
        'buttons.launch': 'LAUNCH',
        'buttons.filter': 'FILTER',
        'buttons.apply_filters': 'APPLY FILTERS',
        'buttons.reset_button': 'RESET ALL',
        'buttons.upload_file': 'UPLOAD FILE',

        'error.data_load_error': 'Error while getting file data',
        'error.primary_party': 'Error occured while updating primary party',

        'footer.copyright_text': 'AXA All Rights Reserved -',

        'general.submission_title': 'Submission Party Extraction & Report Tool',
        'general.search_title': 'Search UI',
        'general.deep_ai_title': 'DEEP AI Solutions',
        'general.ocr_title': 'OCR',
        'general.ocr_ui_title': 'OCR X2TEXT Converter',

        'header.title': 'DEEP AI Platform',
        'header.logout': 'Logout',

        'leftpane.date_between': 'Between',
        'leftpane.date_and': 'And',
        'leftpane.submission_date': 'Submission Date',
        'leftpane.refine_search': 'Refine Your Search',
        'leftpane.clearance_status': 'Clearance Status',
        'leftpane.cleared': 'Cleared',
        'leftpane.not_cleared': 'Not Cleared',
        'leftpane.primary_party': 'Primary Party',
        'leftpane.select_party': 'Select Party',

        'primary_party.table_col_identified': 'Party Identified',
        'primary_party.table_col_duns_number': 'DUNS Number',
        'primary_party.table_col_primary_address': 'Primary Address',
        'primary_party.select': 'Select Primary Party',
        'primary_party.title': 'Select the primary party for this submission from the list of identified parties',

        'login.login_button': 'Login',
        'login.login_request': 'Please login to access the application',

        'submission.drop_files': 'Drag into this box',
        'submission.new': 'New',
        'submission.new_submission_title': 'Enter Your Submission Documents',
        'submission.upload_doc_title': 'Upload Document',
        'submission.new_submission': 'New Submission',
        'success.primary_party': 'Successfully updated the primary party',
        'submission.submission_name': 'Submission name*: ',
        'submission.submission_name_placeholder': 'submission name',
        'submission.upload_documents': 'Upload Document(s)',
        'submission.view_files_title': 'View Files',

        'submission_items.view_idoc': 'VIEW REPORT',
        'submission_items.link_to_doc': 'LINK TO IDOC',
        'submission_items.name': 'Name',
        'submission_items.submitted_on': 'Submitted On',
        'submission_items.files': 'File(s)',
        'submission_items.submission_status': 'Submission Status',
        'submission_items.primary_party': 'Primary Party',
        'submission_items.duns_number': 'DUNS Number',
        'submission_items.clearance_status': 'Clearance Status',
        'submission_items.client_report_url': 'Client Report',
        'submission_items.submission_idoc_Url': 'Submission IDoc',

        'ocr_view.searchable_pdf': 'Searchable PDF'
      },
    },
  },
  fallbackLng: 'en',
  debug: true,

  // have a common namespace used around the full app
  ns: ['translations'],
  defaultNS: 'translations',

  keySeparator: false, // we use content as keys

  interpolation: {
    escapeValue: false, // not needed for react!!
    formatSeparator: ',',
  },

  react: {
    wait: true,
  },
});

export default i18n;
