module.exports = {
  collectCoverageFrom: ["src/**/*.{js,jsx}"],
  setupFilesAfterEnv: ['<rootDir>/config/jest/setupTests.js'],
  testMatch: ["<rootDir>/src/**/__tests__/**/*.{js,jsx}", "<rootDir>/src/**/?(*.)(test).{js,jsx}"],
  transform: {
    "^.+\\.(js|jsx)$": "<rootDir>/config/jest/jest-transformer.js"
  },
  moduleNameMapper: {
    "\\.(jpg|jpeg|png|gif|eot|otf|webp|svg|ttf|woff|woff2|mp4|webm|wav|mp3|m4a|aac|oga)$": "<rootDir>/__mocks__/fileMock.js",
      "\\.(css|less)$": "identity-obj-proxy"
  },
  coverageDirectory: '.coverage',
  transformIgnorePatterns: ["[/\\\\]node_modules[/\\\\].+\\.(js|jsx)$"]
};