import React from 'react';
import { shallow, configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { Pagination } from './Pagination.js';
import renderer from 'react-test-renderer';

configure({ adapter: new Adapter() });

jest.mock('react-i18next', () => ({
  useTranslation: () => ({ t: (key) => key }),
}));

describe('', () => {
  let wrapper;
  let data = [];
  let activePage = 0;

  beforeEach(() => {
    wrapper = shallow(
      <Pagination paginationData={data} activePage={activePage} />,
    );
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('previous button', () => {
    it('should have previous button', async () => {
      // expect(wrapper.find('#prev').text()).toEqual('Previous');

      expect(wrapper.find('#prevPageItem').hasClass('disabled')).toBe(true);
    });
  });

  describe('next button', () => {
    it('should have next button', async () => {
      expect(wrapper.find('#next').text()).toEqual('next');

      expect(wrapper.find('#nextPageItem').hasClass('disabled')).toBe(true);
    });

    it('should set first page active', () => {
      data = [
        { label: '1', isActive: 'active' },
        { label: '2' },
        { label: '3' },
        { label: '4' },
        { label: '5' },
        { label: '6' },
        { label: '7' },
        { label: '8' },
        { label: '9' },
        { label: '10' },
        { label: '11' },
        { label: '12' },
        { label: '13' },
        { label: '14' },
        { label: '15' },
        { label: '16' },
        { label: '17' },
        { label: '18' },
        { label: '19' },
        { label: '20' },
        { label: '21' },
        { label: '22' },
        { label: '23' },
        { label: '24' },
      ];

      wrapper.setProps({ paginationData: data });
      wrapper.setProps({ activePage: 1 });

      expect(wrapper.find('.mb-5 > .active').children().length).toEqual(1);
      expect(wrapper.find('.mb-5 > .active').children().html()).toEqual(
        '<a data-test="page-link" class="page-link">1</a>',
      );
      expect(wrapper.find('.mb-5').children().length).toEqual(26);

      expect(wrapper.find('#prevPageItem').hasClass('disabled')).toBe(true);
      // expect(wrapper.find('#nextPageItem').hasClass('disabled')).toBe(false); // TODO: Not rendering
    });
  });

  describe('previous button', () => {
    it('should have previous button', async () => {
      //expect(wrapper.find('#prev').text()).toEqual('Previous');
      expect(wrapper.find('#prevPageItem').hasClass('disabled')).toBe(true);
    });
  });

  describe('<Pagination /> with pagination data', () => {
    it('should match the snapshot', () => {
      let tree = renderer.create(<Pagination paginationData={data} />).toJSON();
      expect(tree).toMatchSnapshot();
      expect(wrapper.html()).toMatchSnapshot();
    });
  });
});
