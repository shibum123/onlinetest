import React from "react";
// import { Document, Page } from "react-pdf";
import pdfjsWorker from "pdfjs-dist/build/pdf.worker.entry"; // "/pdf.worker.js"
import Viewer, { Worker } from '@phuocng/react-pdf-viewer';
import '@phuocng/react-pdf-viewer/cjs/react-pdf-viewer.css';
import './all-page.scss';

export default function AllPages(props) {
  // const [numPages, setNumPages] = useState(null);

  /* function onDocumentLoadSuccess({ numPages }) {
    setNumPages(numPages);
  } */

  const { pdf } = props;

  return (
    /*  <Document
       file={pdf}
       options={{ workerSrc: pdfjsWorker }}
       onLoadSuccess={onDocumentLoadSuccess}
     >
       {Array.from(new Array(numPages), (el, index) => (
         <Page key={`page_${index + 1}`} pageNumber={index + 1} />
       ))}
     </Document> */
    <Worker workerUrl="https://unpkg.com/pdfjs-dist@2.5.207/build/pdf.worker.min.js">
      <div id="pdfviewer">
        <Viewer fileUrl={pdf} />
      </div>
    </Worker>
  );
}
