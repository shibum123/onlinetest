import * as Msal from 'msal';
import decodeJWT from 'jwt-decode';
import { CLIENT_ID, AUTHORITY_URL, REDIRECT_URI } from '../config';

let loggedUser = {
  isLogged: false,
  email: null,
  name: null,
  access_token: null,
  error: null,
};

export default class AuthService {
  constructor() {
    const PROD_REDIRECT_URI = REDIRECT_URI;
    let redirectUri = window.location.origin;
    if (window.location.hostname !== 'localhost') {
      redirectUri = PROD_REDIRECT_URI;
    }
    const msalConfig = {
      auth: {
        clientId: CLIENT_ID,
        authority: AUTHORITY_URL,
        redirectUri,
      },
      cache: {
        cacheLocation: 'sessionStorage', // This configures where your cache will be stored
        storeAuthStateInCookie: false, // Set this to "true" if you are having issues on IE11 / Edge
      },
    };
    this.app = new Msal.UserAgentApplication(msalConfig);
    this.app.handleRedirectCallback(this.authRedirectCallBack);
  }

  authRedirectCallBack = (error, response) => {
    // eslint-disable-line
    if (error) {
      console.log('Error is: ' + error); // eslint-disable-line
    } else {
      // console.log('resp: ' + response);
      this.getLoggedUser();
    }
  };

  refreshToken = () => {
    return this.app
      .acquireTokenSilent({
        scopes: [CLIENT_ID],
      })
      .then((resp) => {
        return this.getLoggedUser();
      })
      .catch((error) => {
        return null;
      });
  };

  getLoggedUser = () => {
    const id_token = sessionStorage.getItem('msal.idtoken');
    const access_token = sessionStorage.getItem('msal.accesstoken')
      ? sessionStorage.getItem('msal.accesstoken')
      : sessionStorage.getItem('msal.idtoken');
    if (id_token || access_token) {
      loggedUser = {
        isLogged: true,
        email: decodeJWT(id_token).preferred_username,
        name: decodeJWT(id_token).name,
        access_token: access_token ? access_token : null, // eslint-disable-line
        error: null,
      };
    }
    if (
      sessionStorage.getItem('msal.login.error') &&
      sessionStorage.getItem('msal.login.error').split(':')[0] === 'AADSTS50105'
    ) {
      loggedUser.error =
        'Login failed! The user is not assigned to a role for the application. Please contact the administrator.';
    } else {
      loggedUser.error = null;
    }
    return loggedUser;
  };

  login = () => {
    return this.app.loginRedirect({
      scopes: ['user.read'],
    });
  };

  logout = () => {
    sessionStorage.removeItem('msal.idtoken');
    sessionStorage.removeItem('msal.accesstoken');
    this.app.logout();
  };

  getUserDetails = () => {
    return this.getLoggedUser();
  };
}
