import React from 'react';
import { withRouter } from 'react-router-dom';
import AppRoutes from './AppRoutes';
import Snackbar from '../common/Snackbar';
import { Header } from '../header/Header';
import { Footer } from '../footer/Footer';
import { previousUrlKeyName } from '../../constants/constants';

const BaseLayout = () => {
  const previousUrl = sessionStorage.getItem(previousUrlKeyName);

  if (previousUrl) {
    sessionStorage.removeItem(previousUrlKeyName);
    window.location.href = previousUrl;
  }

  return (
    <>
      <Header />
      <AppRoutes />
      <Footer />
      <Snackbar />
    </>
  );
};

export default withRouter(BaseLayout);
