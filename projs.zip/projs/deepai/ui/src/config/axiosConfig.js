import axios from 'axios';
import { previousUrlKeyName } from '../constants/constants';

export default () => {
  // Add a 401 response interceptor
  axios.interceptors.response.use(
    function (response) {
      return response;
    },
    function (error) {
      if (401 === error.response.status) {
        sessionStorage.setItem(previousUrlKeyName, window.location.href);
        window.location.href = '/oauth2/authorization/login-client';
      } else {
        return Promise.reject(error);
      }
    }
  );
};
