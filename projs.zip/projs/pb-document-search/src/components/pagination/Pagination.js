import React, { useState, useEffect } from 'react';
import {
  MDBPagination,
  MDBPageItem,
  MDBPageNav,
  MDBCol,
  MDBRow,
} from 'mdbreact';
import './Pagination.scss';
import { useTranslation } from 'react-i18next';

export const Pagination = (props) => {
  const [currentPage, setCurrentPage] = useState(-1);
  const { t } = useTranslation();

  const isPrevDisabled = () => {
    return currentPage <= 1;
  };
  const isNextDisabled = () => {
    return (
      currentPage < 1 ||
      props.paginationData.length === 0 ||
      currentPage === props.paginationData.length
    );
  };

  useEffect(() => {
    props.paginationData.forEach((item, index) => {
      if (item.isActive === 'active') {
        setCurrentPage(item.label);
      }
    });
  }, [props.paginationData, props.activePage]);

  return (
    <MDBRow>
      <MDBCol>
        <MDBPagination className="mb-5">
          <MDBPageItem
            id="prevPageItem"
            className={isPrevDisabled() ? 'disabled' : ''}
            onClick={() => props.handlePageChange(currentPage - 1)}>
            <MDBPageNav aria-label={t('previous')}>
              <span id="prev" aria-hidden="true">
                {t('previous')}
              </span>
            </MDBPageNav>
          </MDBPageItem>
          {props.paginationData.map((item, index) => {
            return (
              <MDBPageItem
                key={item + index}
                className={item.isActive}
                onClick={() => props.handlePageChange(item.label)}>
                <MDBPageNav>{item.label}</MDBPageNav>
              </MDBPageItem>
            );
          })}
          <MDBPageItem
            id="nextPageItem"
            className={isNextDisabled() ? 'disabled' : ''}
            onClick={() => props.handlePageChange(currentPage + 1)}>
            <MDBPageNav aria-label={t('previous')}>
              <span id="next" aria-hidden="true">
                {t('next')}
              </span>
            </MDBPageNav>
          </MDBPageItem>
        </MDBPagination>
      </MDBCol>
    </MDBRow>
  );
};
