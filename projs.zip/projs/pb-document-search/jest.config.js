const transformIgnorePatterns = [
    '/dist/',
    'node_modules\/[^/]+?\/(?!(axa-xl|node_modules)\/)', // Ignore modules without axa-xl dir
];