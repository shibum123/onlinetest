import moment from 'moment';

export const SET_SUBMISSIONS = 'dap/submissions/SET_SUBMISSIONS';
export const SET_FILTER = 'dap/submissions/SET_FILTER';
export const SET_SHOW_EDIT_SUBMISSION = 'dap/submissions/SET_SHOW_EDIT_SUBMISSION';
export const SET_SHOW_VIEW_FILES = 'dap/submissions/SET_SHOW_VIEW_FILES';
export const SET_FILES = 'dap/submissions/SET_FILES';
export const SHOW_PRIMARY_DIALOG = 'dap/submissions/SHOW_PRIMARY_DIALOG';
export const SET_PARTIES = 'dap/submissions/SET_PARTIES';

const initialState = {
    submissions: [],
    allSubmissions: [],
    filterObj: null,
    showEditSubmission: false,
    showViewFiles: false,
    submission: { id: null, name: null }, // selected submission
    selectedFileIds: [],
    files: [],
    parties: [],
    showPartyDialog: false,
    partySubmissionId: null
};

const getPrimaryParty = (item) => {
    let companyName = null;
    if (item['report'] && item['report'].companies) {
        item['report'].companies.forEach(company => {
            if (item['report'].primary === company.id) {
                companyName = company.companyName
            }
        })
    }
    return companyName;
}

export const filterResults = (allSubmissions, filterObj) => {
    let filtered = allSubmissions;
    if (!((filterObj.primary_party === '' || filterObj.primary_party === null || filterObj.primary_party === undefined) && (filterObj.name === '') && (filterObj.startdate === null || filterObj.startdate === undefined) && (filterObj.enddate === null || filterObj.startdate === undefined))) {
        filtered = allSubmissions.filter((item) => {
            const isEmptyName = filterObj.name === '';
            const isEmptyParty = (filterObj.primary_party === '' || filterObj.primary_party === null || filterObj.primary_party === undefined);
            const submissionTime = moment(new Date(item['submittedTime'] * 1000)).format('YYYY-MM-DD');

            if (!isEmptyName) {
                return (item.name.toLowerCase().indexOf(filterObj.name.toLowerCase()) >= 0);
            } else if (!isEmptyParty && getPrimaryParty(item)) {
                const start_date = moment(filterObj.startdate).format('YYYY-MM-DD');
                const end_date = moment(filterObj.enddate).format('YYYY-MM-DD');
                return (getPrimaryParty(item).toLowerCase().indexOf(filterObj.primary_party.toLowerCase()) >= 0 &&
                    (submissionTime >= start_date) &&
                    (submissionTime <= end_date));
            } else if (!isEmptyParty) {
                return false;
            } else {
                const start_date = moment(filterObj.startdate).format('YYYY-MM-DD');
                const end_date = moment(filterObj.enddate).format('YYYY-MM-DD');
                return (submissionTime >= start_date) &&
                    (submissionTime <= end_date)
            }
        })
    }
    return filtered;
}

export default (state = initialState, action) => {
    switch (action.type) {
        case SET_SHOW_EDIT_SUBMISSION:
            const { showEditSubmission, submission, selectedFiles } = action;

            return {
                ...state,
                showEditSubmission,
                submission: !submission ? initialState.submission : submission,
                selectedFileIds: selectedFiles
            };
        case SET_SHOW_VIEW_FILES:
            const { showViewFiles, selected_files } = action;

            return {
                ...state,
                showViewFiles,
                selectedFileIds: selected_files
            };
        case SET_FILES:
            const { files } = action;
            return {
                ...state,
                files
            };

        case SHOW_PRIMARY_DIALOG:
            const { showPartyDialog, partySubmissionId } = action;
            return {
                ...state,
                showPartyDialog,
                partySubmissionId
            };
        case SET_SUBMISSIONS:
            const { submissions } = action;
            state.allSubmissions = submissions;
            return {
                ...state,
                submissions
            };
        case SET_PARTIES:
            const { parties } = action;
            return {
                ...state,
                parties
            };
        case SET_FILTER:
            const { filterObj } = action;
            return {
                ...state,
                submissions: filterResults(state.allSubmissions, filterObj)
            };
        default:
            return state;
    }
};

export const setSubmissions = (
    submissions
) => ({
    type: SET_SUBMISSIONS,
    submissions
});

export const setFilter = (
    filterObj
) => ({
    type: SET_FILTER,
    filterObj
});

export const setEditSubmission = (
    showEditSubmission,
    submission,
    selectedFiles
) => ({
    type: SET_SHOW_EDIT_SUBMISSION,
    showEditSubmission,
    submission,
    selectedFiles
});

export const setViewFiles = (
    showViewFiles,
    selected_files
) => ({
    type: SET_SHOW_VIEW_FILES,
    showViewFiles,
    selected_files
});

export const setFiles = (
    files
) => ({
    type: SET_FILES,
    files
});

export const setShowPartyDialog = (
    showPartyDialog,
    partySubmissionId = null
) => ({
    type: SHOW_PRIMARY_DIALOG,
    showPartyDialog,
    partySubmissionId
});

export const setParties = (
    parties
) => ({
    type: SET_PARTIES,
    parties
})