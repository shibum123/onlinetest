import React, { useEffect } from 'react';
import Typography from '@axaxl-web/typography';
import Button from '@axaxl-web/button';
import Icon from '@axaxl-web/icon';

import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { setFiles } from '../../redux/ducks/submissions';
import { Submissions } from './Submissions';

import './ViewFiles.scss';

const ViewFiles = (props) => {
    const { t } = useTranslation();
    const { selectedFileIds } = useSelector(state => state.submissions)

    const submissions = new Submissions();
    const dispatch = useDispatch();

    useEffect(() => {
        submissions.downloadSubmissionFile(selectedFileIds)
            .then(data => {
                b64toBlob(data);
            })
    }, [selectedFileIds, b64toBlob]); // eslint-disable-line

    const b64toBlob = async (imageDataUrls) => {
        const fileArray = [];
        if (imageDataUrls && imageDataUrls.length > 0) {
            imageDataUrls.forEach((imageDataUrl, index) => {
                fetch(`data:${imageDataUrl.fileType};base64,${imageDataUrl.data}`).then(res => {
                    res.arrayBuffer().then(buf => {
                        const tmpFile = new File([buf], imageDataUrl.filename, { type: imageDataUrl.fileType });
                        tmpFile.id = imageDataUrl.id;
                        fileArray.push(tmpFile);
                        if (index === imageDataUrls.length - 1) {
                            dispatch(setFiles(fileArray));
                        }
                    })
                })

                const link = document.createElement('a');
                const file_name = imageDataUrl.filename;
                const _index = file_name.lastIndexOf('.');

                let file_part = file_name;
                let extension_part;

                if (_index > 0) {
                    file_part = file_name.substring(0, _index);
                    extension_part = file_name.substring(_index, file_name.length);
                }

                const _text = _index > 10 ? `${file_part.substring(0, 10)}...${extension_part}` : file_name;

                link.href = `data:${imageDataUrl.fileType};base64,${imageDataUrl.data}`;
                link.title = file_name;
                link.setAttribute('download', imageDataUrl.filename);

                const _div = document.createElement('div');

                const _div2 = document.createElement('div');
                _div2.setAttribute('class', 'viewfiles__file_container');
                _div.appendChild(_div2);

                const fileIcon = document.getElementById('fileIcon');
                const clone = fileIcon.cloneNode(true);
                clone.id = `file_icon${index}`;
                clone.setAttribute("class", "file_icon");
                _div2.appendChild(clone);

                const label = document.createElement('label');

                label.append(_text);
                _div.appendChild(label);

                link.appendChild(_div);

                document.getElementById('downloads').appendChild(link);
                const span = document.createElement('span');
                span.append(' ');
                document.getElementById('downloads').appendChild(span);
            })
        }
    };

    return <div className="viewfiles">
        <div className="viewfiles__title_container">
            <Typography variant="moduleTitle" className="viewfiles__title" >{t('submission.view_files_title')}</Typography>
            <Icon fontSize="medium" color="primary" name="close" className="viewfiles__close" onClick={props.handleOnClose} />
        </div>
        <div id="downloads" className="viewfiles__download_links"></div>
        <div className="viewfiles__button-container">
            <Button className="viewfiles__button" onClick={props.handleOnClose} color="secondary">{t('buttons.close')}</Button>&nbsp;&nbsp;&nbsp;
        </div>
    </div>
}

export default ViewFiles;