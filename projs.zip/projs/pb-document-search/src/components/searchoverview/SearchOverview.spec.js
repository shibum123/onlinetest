import React from 'react';
import ReactDOM from 'react-dom';
import SearchOverview from './SearchOverview';
import { render } from '@testing-library/react';
import { SearchContext } from '../../App';
import renderer from 'react-test-renderer';
import '@testing-library/jest-dom/extend-expect';

jest.mock('react-router-dom', () => {
  const historyObj = {
    push: jest.fn(),
  };

  return {
    ...jest.requireActual('react-router-dom'),
    useHistory: () => historyObj,
    useLocation: () => ({
      pathname: '/search',
    }),
  };
});

jest.mock('react-i18next', () => ({
  useTranslation: () => ({ t: (key) => key }),
}));

/* jest.spyOn(SearchOverview, 'searchContext').mockImplementation(() => {
    typedString: ''
}) */

it('renders without crashing', () => {
  const div = document.createElement('div');
  ReactDOM.render(
    <SearchContext.Provider value={{ searchState: '', searchDispatch: null }}>
      <SearchOverview />
    </SearchContext.Provider>,
    div,
  );
});

it('should render search tool text correctly', () => {
  const { getByTestId } = render(
    <SearchContext.Provider value={{ searchState: '', searchDispatch: null }}>
      <SearchOverview />
    </SearchContext.Provider>,
  );
  expect(getByTestId('searchtool-text')).toHaveTextContent(
    'searchheader_searchtool',
  );
});

it('should match the snapshot', () => {
  let tree = renderer
    .create(
      <SearchContext.Provider value={{ searchState: '', searchDispatch: null }}>
        <SearchOverview />
      </SearchContext.Provider>,
    )
    .toJSON();
  expect(tree).toMatchSnapshot();
});
