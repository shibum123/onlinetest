import React from 'react';
import { useTranslation } from 'react-i18next';
import Copyright from '@axaxl-web/copyright';
import './Footer.scss';

export const Footer = () => {
    const { t } = useTranslation();
    return <div className="footer"><Copyright
        copyrightText={t('footer.copyright_text')}
        copyrightHref="https://www.axa.com/en/page/privacy-policy" />
    </div>
}
