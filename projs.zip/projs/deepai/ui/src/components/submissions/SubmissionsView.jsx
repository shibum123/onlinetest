import React, { useEffect, useState } from 'react';
import Button from '@axaxl-web/button';
import SearchBar from '@axaxl-web/search-bar';
import Modal from '@axaxl-web/modal';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { Submissions } from './Submissions';
import './Submissions.scss';
import { setSnackbar } from '../../redux/ducks/general';
import { setFilter, setFiles, setSubmissions, setEditSubmission, setShowPartyDialog, setViewFiles } from '../../redux/ducks/submissions';
import NewSubmission from './NewSubmission';
import ViewFiles from './ViewFiles';
import SubmissionItems from './SubmissionItems';
import PrimaryPartySelection from './PrimaryPartySelection';
import LeftPane from './../ui/LeftPane';
import { slide as Menu } from 'react-burger-menu';

const SubmissionsView = () => {
    const { t } = useTranslation();
    const [openSubmission, setOpenSubmission] = useState(false);
    const { showViewFiles } = useSelector(state => state.submissions);
    const { showEditSubmission } = useSelector(state => state.submissions)
    const { id } = useSelector(state => state.submissions.submission)
    const { showPartyDialog } = useSelector(state => state.submissions);
    const [isOpen, setIsOpen] = useState(false);

    const allSubmissions = new Submissions();
    const dispatch = useDispatch();

    const dispatchSubmissions = () => {
        allSubmissions.getAllSubmissions()
            .then((resp) => {
                dispatch(setSubmissions(resp ? resp : []))
            }).catch(error => {
                dispatch(setSnackbar(true, 'error', 'Error occured while loading data'));
            })
    }

    useEffect(() => {
        dispatchSubmissions();
    }, []); // eslint-disable-line

    const onNewSubmission = () => {
        setOpenSubmission(true);
    }

    const onFilter = () => {
        setIsOpen(!isOpen)
    }

    const handleOnClose = () => {
        setOpenSubmission(false);
        dispatch(setFiles([]));
        dispatch(setEditSubmission(false, null, null));
    }

    const handleOnViewClose = () => {
        dispatch(setFiles([]));
        dispatch(setViewFiles(false, null));
    }

    const handlePartyClose = () => {
        dispatch(setShowPartyDialog(false));
        dispatchSubmissions();
    }

    const onTextChange = (target) => {
        dispatch(setFilter({ name: target.value }));
    }

    const deleteSubmission = (id) => {
        if (id) {
            allSubmissions.deleteSubmission(id)
                .then(resp => {
                    if (!resp) {
                        dispatch(setSnackbar(true, 'error', 'Error occured while deleting the submission'));
                    } else {
                        dispatch(setSnackbar(true, 'success', 'Successfully deleted the submission'));
                        handleOnClose();
                        dispatchSubmissions();
                    }
                }).catch(error => {
                    dispatch(setSnackbar(true, 'error', 'Error occured while deleting the submission'));
                });
        } else {
            dispatch(setSnackbar(true, 'error', 'Error occured while deleting the submission'));
        }
    }

    const onSubmit = (req) => {
        if (showEditSubmission) {
            allSubmissions.editSubmission(req, id)
                .then(resp => {
                    if (!resp) {
                        dispatch(setSnackbar(true, 'error', 'Error occured while creating the submission'));
                    } else {
                        dispatch(setSnackbar(true, 'success', 'Successfully updated the submission'));
                        handleOnClose();
                        dispatchSubmissions();
                    }
                }).catch(error => {
                    dispatch(setSnackbar(true, 'error', 'Error occured while creating the submission'));
                });
        } else {
            allSubmissions.createSubmission(req)
                .then(resp => {
                    if (!resp) {
                        dispatch(setSnackbar(true, 'error', 'Error occured while creating the submission'));
                    } else {
                        dispatch(setSnackbar(true, 'success', 'Successfully submitted the submission'));
                        handleOnClose();
                        dispatchSubmissions();
                    }
                }).catch(error => {
                    dispatch(setSnackbar(true, 'error', 'Error occured while creating the submission'));
                });
        }
    }

    const applyFilter = (filterObj) => {
        dispatch(setFilter(filterObj));
        setIsOpen(false);
    }

    const handleFilterOnClose = () => {
        setIsOpen(false);
    }

    return <div id="outer-container">
        <Menu
            isOpen={isOpen}
            customBurgerIcon={false}
            noOverlay
            outerContainerId="outer-container"
            pageWrapId="page-wrap"
            width="360px"
        >
            <LeftPane applyFilter={applyFilter} handleOnClose={handleFilterOnClose} />
        </Menu>
        <div className="submissions" id="page-wrap">
            <Modal open={openSubmission || showEditSubmission}>
                <div className="submissions__modalStyle" onClose={handleOnViewClose}>
                    <NewSubmission handleOnClose={handleOnClose} onSubmit={(name) => onSubmit(name)} deleteSubmission={(id) => deleteSubmission(id)} />
                </div>
            </Modal>
            <Modal open={showViewFiles}>
                <div className="submissions__modalStyle" onClose={handleOnViewClose}>
                    <ViewFiles handleOnClose={handleOnViewClose} />
                    <div className="submissions__fileIcon">
                        <svg id="fileIcon" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M16.5 6v11.5c0 2.21-1.79 4-4 4s-4-1.79-4-4V5c0-1.38 1.12-2.5 2.5-2.5s2.5 1.12 2.5 2.5v10.5c0 .55-.45 1-1 1s-1-.45-1-1V6H10v9.5c0 1.38 1.12 2.5 2.5 2.5s2.5-1.12 2.5-2.5V5c0-2.21-1.79-4-4-4S7 2.79 7 5v12.5c0 3.04 2.46 5.5 5.5 5.5s5.5-2.46 5.5-5.5V6h-1.5z"></path></svg>
                    </div>
                </div>
            </Modal>
            <Modal open={showPartyDialog} >
                <PrimaryPartySelection handlePartyClose={handlePartyClose} className="submissions__showPartyModal" />
            </Modal>
            <div className="submissions__container">
                <div className="submissions__button-container">
                    <Button className="submissions__button" onClick={onNewSubmission}>
                        {t('submission.new_submission')}
                    </Button>
                </div>
                <Button className="submissions__filter-button" color="secondary" onClick={onFilter}>
                    {t('buttons.filter')}
                </Button>&nbsp;&nbsp;&nbsp;&nbsp;
            <SearchBar className="submissions__search-text" inputProps={{
                    placeholder: "Search",
                    onKeyPress: (event) => {
                        if (event.charCode === 13) {
                            onTextChange(event.currentTarget)
                        }
                    }

                }}
                    buttonProps={{
                        color: 'primary',
                        onClick: (event) => onTextChange(event.currentTarget.parentElement.children[0].children[0]),
                    }}
                />
            </div>
            <SubmissionItems allSubmissions={allSubmissions} dispatchSubmissions={dispatchSubmissions} onNewSubmission={onNewSubmission} />
        </div>
    </div>
}

export default SubmissionsView;