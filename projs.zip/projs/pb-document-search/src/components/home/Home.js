import React, { useState } from 'react';
import './Home.scss';
import { useHistory } from 'react-router-dom';
import { SearchHeader } from '../searchheader/SearchHeader';
import logo from '../../assets/deep-ai.svg';
import { useTranslation } from 'react-i18next';
import '../searchoverview/SearchOverview.scss';

export const Home = (props) => {
  const [disabled, setDisabled] = useState(true);
  const [typedString, setTypedString] = useState('');
  const history = useHistory();
  const { t } = useTranslation();

  const handleOnChange = (event) => {
    setTypedString(event.target.value);
    if (event.target.value) {
      setDisabled(event.target.value.trim() === '');
    } else {
      setDisabled(true);
    }
  };

  const handleMouseClick = () => {
    if (!disabled) {
      history.push({
        pathname:
          document.getElementById('isKeywordSearch').checked === true
            ? '/search'
            : '/semantic',
        state: { searchText: typedString },
      });
    }
  };

  const handleKeyDown = (evt) => {
    if (evt.key === 'Enter' && evt.target.value) {
      handleMouseClick();
    }
  };

  return (
    <div className="home">
      <SearchHeader
        enableLogin={props.enableLogin}
        login={props.login}
        logout={props.logout}
        loggedUser={props.loggedUser}
      />
      <div className="input-group home__header">
        <div className="home__search-container">
          <img
            width="168px"
            height="48px"
            className="home__search-item"
            src={logo}
            alt="deep ai logo"
          />
          <div className="input-group home__search-item">
            <input
              className="form-control border-right-0 border search__input-element"
              type="search"
              onChange={handleOnChange}
              onKeyDown={handleKeyDown}
              placeholder={t('searchinput_searching_for')}
              aria-label={t('searchinput_searching_for')}
            />
            <span className="input-group-append search__input">
              <div className="input-group-text bg-transparent">
                <i className="fa fa-search" onClick={handleMouseClick}></i>
              </div>
            </span>
          </div>
          <div className="home__inline">
            <div className="home__help">
              <div className="home__help-circle">
                <div className="home__help-circle-text">?</div>
                <span className="home__help__tool-tip">{t('search_ui')}</span>
              </div>
              {t('help')}
            </div>
            <div className="home__button-container">
              <input
                type="button"
                className="search-overview__button"
                onClick={handleMouseClick}
                value={t('search_button')}
                disabled={disabled}
                tabIndex="2"
              />
              <label
                className="advanced_search__text-aligned home__container"
                htmlFor="isKeywordSearch">
                {t('exact_match')}
                <input type="checkbox" id="isKeywordSearch" />
                <span className="checkmark"></span>
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
