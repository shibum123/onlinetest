import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

export default function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    //if page is loaded via push state, scroll back to top of inner content area
    if (document.getElementById('inner-content')) {
      if (document.getElementById('inner-content').scrollTo) {
        document.getElementById('inner-content').scrollTo(0, 0);
      } else {
        document.getElementById('inner-content').scrollTop = 0;
      }
    }
  }, [pathname]);

  return null;
}
