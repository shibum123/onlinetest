import React from 'react';
import Highlighter from 'react-highlight-words';
import './ShowDocument.scss';

export const ShowDocument = (prop) => {
  return (
    <Highlighter
      className="showDocument__text"
      highlightClassName="showDocument__highlight"
      searchWords={prop.searchWords ? prop.searchWords : []}
      autoEscape={true}
      textToHighlight={
        prop.document && prop.document.content ? prop.document.content : ''
      }
    />
  );
};
