import { useDispatch } from "react-redux";
import { setSnackbar } from "./redux/ducks/general";

export class ErrorHandler {

    constructor() {
        this.dispatch = useDispatch();
    }

    handleErrors(err, message) {
        console.error("Error occured during " + message);
        console.error(err);
        this.dispatch(setSnackbar(true, "error", 'Data load error has occured'));
    }
}
export default ErrorHandler;