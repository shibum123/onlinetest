export const REACT_APP_BASE_URL = 'http://localhost:8080/search' // API_BASE_URL_REPLACE_HERE__PLACEHOLDER';
export const REACT_APP_REDIRECT_URI =
  'APP_REDIRECT_URI_REPLACE_HERE__PLACEHOLDER';
export const REACT_APP_DOC_SOURCE = 'documentum';
export const INDEX_NAME = 'azureblob-index';
