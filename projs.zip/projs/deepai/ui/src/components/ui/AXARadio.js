import React from 'react';
import {
    withStyles
} from '@material-ui/core/styles';
import AxaRadioButton from './Radio';

const AxaRadio = withStyles({
    root: {
        color: '#cccccc',
        '&.Mui-checked': {
            color: '#00008f',
        },
        '&:hover': {
            backgroundColor: `${'#cccccc'}20`,
        },
        '&:active': {
            color: '#00008f',
            backgroundColor: `${'#cccccc'}20`,
        },
        '&.Mui-disabled': {
            color: '#cccccc',
            mouseEvents: 'none',
            opacity: 1,
        },
    },
    checked: {
        color: '#00008f'
    }
})((props) => <AxaRadioButton color="default" {...props} />);

export default AxaRadio;