import React, { useContext } from 'react';
import './SearchInput.scss';
import { SearchContext } from '../../App';
import { useTranslation } from 'react-i18next';

export const SearchInput = (props) => {
  const searchContext = useContext(SearchContext);
  const { t } = useTranslation();

  return (
    <div className="searchinput">
      <div className="input-group">
        <input
          className="form-control border-right-0 border search__input-element"
          type="search"
          ref={props.inputField}
          value={searchContext.searchState.typedString || ''}
          placeholder={t('searchinput_searching_for')}
          onChange={props.handleOnChange}
          onKeyDown={props.handleKeyDown}
          aria-label={t('searchinput_searching_for')}
          tabIndex="1"
          height="40px"
        />
        <span className="input-group-append search__input">
          <div className="input-group-text bg-transparent">
            <i className="fa fa-search" onClick={props.handleMouseClick}></i>
          </div>
        </span>
      </div>
    </div>
  );
};
